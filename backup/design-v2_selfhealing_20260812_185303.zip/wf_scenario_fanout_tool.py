import requests
from typing import Any, Type, Union, List, Dict
from pydantic import BaseModel, Field
from crewai.tools import BaseTool
import json
import AVASecret

# Target pipeline for Workflow 2 (testcase gen + reviewer + circuit breaker).
_WORKFLOW2_PIPELINE_ID = 176

# Priority is always hardcoded; it is not received from the agent.
_PRIORITY = 1

# Every scenario starts its self-healing loop at attempt 1.
_INITIAL_ATTEMPT = 1


class ScenarioFanOutSchema(BaseModel):
    """Input schema for ScenarioFanOutCaller."""

    scenariojson: Union[str, List[Any], Dict[str, Any]] = Field(
        ...,
        description=(
            "The full array of test scenarios produced by the Scenario Gen "
            "agent. May be a JSON string or a JSON array of scenario objects, "
            "each with scenarioId, title, acceptanceCriteriaRef, type, "
            "description, priority. Do NOT include priority/pipelineId/caseIndex "
            "at the top level; the tool sets those itself."
        ),
    )


class ScenarioFanOutCaller(BaseTool):
    """
    ScenarioFanOutCaller - Receives the full scenario array from the Scenario
    Gen agent, splits it, and triggers Workflow 2 (pipeline 163) once per
    scenario. Each call carries a single scenario plus caseIndex (1..N) and
    attempt=1 so the downstream circuit breaker can bound the self-healing loop.
    """

    name: str = "Scenario Fan-Out Caller"
    description: str = (
        "Splits the scenario array and triggers Workflow 2 once per scenario, "
        "seeding caseIndex and attempt for the self-healing circuit breaker."
    )
    args_schema: Type[BaseModel] = ScenarioFanOutSchema

    def _run(self, scenariojson: Union[str, List[Any], Dict[str, Any]]) -> str:
        try:
            api_url = "https://aava-core-api-workflows-svc.redtree-f4541a84.eastus.azurecontainerapps.io/workflows/workflow-executions"

            # pat_token = AVASecret.getValue("KEY")
            pat_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJIcmlzaGlrZXNoIFJvZGUiLCJpYXQiOjE3ODU4MzM3NDEsImV4cCI6MTc5ODc2MTU5OSwiYXBwaWQiOiIyZTAwNzA4ZS05ZjZlLTQxODYtOWQxNy04MTRjZjI1YWI2M2EiLCJ1bmlxdWVfbmFtZSI6IkhyaXNoaWtlc2guUm9kZUBjYXJlc291cmNlLmNvbSIsImRvbWFpbiI6ImFhdmEtY29yZS1hcGktYXV0aC1zdmMucmVkdHJlZS1mNDU0MWE4NC5lYXN0dXMuYXp1cmVjb250YWluZXJhcHBzLmlvIiwidXNlckRldGFpbHMiOiJyRnR6Q0J4MkpWbGtjNHU0UlRZQ0RGcjRDaGhsM0NEWDdWb2Z0Y2R1WGc1REZ1Z1VCSXFQSjIzRFV2TzVGajR6OHVBRnZLam9rMjhrRWhmSGxra1F5a1J4QmpVci94UEtsRHdVMkVUdko0SVhJY1ZJZ3lVQ2pPNzlYWmVIRm1pQ052SDd5bU04UCtNUmpIMEt0RFI3ME9OdWNUZzZwOTYrOHNjc0h1Q2hXdVBjZ0JGRFl1UlhGVGhUVXVvMHRiZFRuOGNjZDcwVHYrRStpTys2Y2M4NUNHa0ZlTkhxNHBid0JNRUhMdjBpSXNJPSJ9.J1vMecZNQdN9F2v_mJe4G5iDok6Fy7KnYB2DUSDxTpuw_ZBqmNF19i5ewpBBsUZbaf8xZN4PHdjTrtjgBj_ewHr2jMhlOQGMU8luPEYwpX1vi28H8wRFepN5k-tMB6YVnQ0jnU5HcjtoKeTyuDVf6oXIty8v41B7hVI1hjFqdDlL0G_gwoRSFbFjatsjYv4_QlRAhmD6w8L6S3oqTrO37PvgO4u-ltIGuK4DZMUIUh6mJT7Od9IUEBTr6wlWp_SoiaqKMe-4yUT-_VpHpl1CWHGY4wyCB9deXi9sYb33khWLRYwh8Q68M3pIBUktezw-66ttLSNe0tSxYGUjKZPhQg"

            headers = {
                "Authorization": f"Bearer {pat_token}",
            }

            # Accept either a JSON string or an already-parsed array/object.
            def coerce_scenarios(value):
                if isinstance(value, str):
                    value = json.loads(value)
                if isinstance(value, dict):
                    value = [value]
                if not isinstance(value, list):
                    raise ValueError(
                        "scenariojson must be a JSON array of scenario objects"
                    )
                return value

            # Normalize all values to strings for multipart form-data encoding.
            # Nested dicts/lists are JSON-serialized.
            def normalize_form_data(data: dict) -> dict:
                normalized = {}
                for key, value in data.items():
                    if isinstance(value, (dict, list)):
                        normalized[key] = json.dumps(value)
                    elif value is None:
                        normalized[key] = ""
                    else:
                        normalized[key] = str(value)
                return normalized

            try:
                scenarios = coerce_scenarios(scenariojson)
            except (ValueError, json.JSONDecodeError) as e:
                return f"Error: could not parse scenariojson: {str(e)}"

            if not scenarios:
                return "Error: scenariojson is empty; nothing to fan out."

            results = []
            for index, scenario in enumerate(scenarios, start=1):
                scenario_id = (
                    scenario.get("scenarioId", "")
                    if isinstance(scenario, dict)
                    else ""
                )

                form_data = {
                    "pipelineId": _WORKFLOW2_PIPELINE_ID,
                    "priority": _PRIORITY,
                    "userInputs": {
                        # One scenario per call, wrapped as a single-element
                        # array so testcase-gen still receives an array.
                        "tsInputJson_string_true": json.dumps([scenario]),
                        "rvwFeedbackTxt_string_false": "",
                        "caseIndex": index,
                        "attempt": _INITIAL_ATTEMPT,
                    },
                }

                normalized = normalize_form_data(form_data)

                try:
                    response = requests.post(
                        api_url,
                        files={k: (None, v) for k, v in normalized.items()},
                        headers=headers,
                    )
                    response.raise_for_status()
                    try:
                        body = response.json()
                    except Exception:
                        body = response.text
                    results.append(
                        f"case {index} ({scenario_id}): triggered -> {body}"
                    )
                except requests.RequestException as e:
                    results.append(
                        f"case {index} ({scenario_id}): ERROR -> {str(e)}"
                    )

            header = (
                f"Fan-out complete: {len(scenarios)} scenario(s) -> "
                f"pipeline {_WORKFLOW2_PIPELINE_ID}."
            )
            return header + "\n" + "\n".join(results)

        except requests.RequestException as e:
            return f"Error during API call: {str(e)}"
