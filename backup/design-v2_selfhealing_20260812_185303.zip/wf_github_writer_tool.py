import time
from typing import Any, Type
import requests
from pydantic import BaseModel, Field
from crewai.tools import BaseTool

# Repo config — hardcoded in the AAVA container (like the caller PAT pattern).
_REPO_OWNER = ""
_REPO_NAME = ""
_BASE_BRANCH = "main"

# Single stable branch all cases append to, so 1.txt..N.txt land together.
_OUTPUT_BRANCH = "self-healing-testcases"

# Retries for the branch ref update, to survive concurrent per-case writers.
_MAX_REF_RETRIES = 5


class GithubWriterSchema(BaseModel):
    """Input schema for GithubWriterTool."""

    files: dict = Field(
        ...,
        description=(
            "Dict of {filepath: content} to commit. For the self-healing design "
            "this is a single entry like {'5.txt': '<approved test cases>'} where "
            "the key is the caseIndex."
        ),
    )
    branch: str = Field(
        default="",
        description="Target branch to append to. Defaults to the output branch.",
    )
    commit_message: str = Field(
        default="",
        description="Optional commit message.",
    )


class GithubWriterTool(BaseTool):
    """
    GithubWriterTool - Commits per-case output files to a GitHub repo on the
    Workflow 2 PASS path. Targets ONE stable output branch and APPENDS each file
    (auto-creating the branch from base if missing), so 1.txt..N.txt from all
    passing cases land together for Workflow 3 to aggregate.
    """

    name: str = "Github Writer"
    description: str = (
        "Commits per-case '{caseIndex}.txt' output to a stable GitHub branch, "
        "appending each file and auto-creating the branch from base if missing."
    )
    args_schema: Type[BaseModel] = GithubWriterSchema

    def _headers(self, token: str) -> dict:
        return {
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github+json",
            "User-Agent": "Self-Healing-Agent",
        }

    def _get_branch_sha(self, base_api: str, branch: str, headers: dict):
        resp = requests.get(f"{base_api}/git/ref/heads/{branch}", headers=headers)
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()["object"]["sha"]

    def _commit_tree_sha(self, base_api: str, commit_sha: str, headers: dict) -> str:
        resp = requests.get(f"{base_api}/git/commits/{commit_sha}", headers=headers)
        resp.raise_for_status()
        return resp.json()["tree"]["sha"]

    def _ensure_branch(self, base_api: str, branch: str, base_branch: str, headers: dict) -> str:
        sha = self._get_branch_sha(base_api, branch, headers)
        if sha is not None:
            return sha
        base_sha = self._get_branch_sha(base_api, base_branch, headers)
        if base_sha is None:
            raise RuntimeError(
                f"Base branch '{base_branch}' not found. Initialize the repo first."
            )
        resp = requests.post(
            f"{base_api}/git/refs",
            headers=headers,
            json={"ref": f"refs/heads/{branch}", "sha": base_sha},
        )
        resp.raise_for_status()
        return base_sha

    def _run(self, files: dict, branch: str = "", commit_message: str = "") -> Any:
        if not files:
            return {"status": "failure", "message": "No files provided to commit."}

        branch = branch or _OUTPUT_BRANCH
        if not _REPO_OWNER or not _REPO_NAME:
            return {
                "status": "failure",
                "message": "_REPO_OWNER / _REPO_NAME are not configured.",
            }

        # token = AVASecret.getValue("GITHUB_TOKEN")
        token = ""

        headers = self._headers(token)
        base_api = f"https://api.github.com/repos/{_REPO_OWNER}/{_REPO_NAME}"

        tree_items = [
            {
                "path": path.lstrip("/"),
                "mode": "100644",
                "type": "blob",
                "content": content,
            }
            for path, content in files.items()
        ]
        message = commit_message or f"self-healing output: {', '.join(files.keys())}"

        last_error = None
        for _ in range(_MAX_REF_RETRIES):
            try:
                head_sha = self._ensure_branch(base_api, branch, _BASE_BRANCH, headers)
                base_tree = self._commit_tree_sha(base_api, head_sha, headers)

                tree_resp = requests.post(
                    f"{base_api}/git/trees",
                    headers=headers,
                    json={"base_tree": base_tree, "tree": tree_items},
                )
                tree_resp.raise_for_status()
                new_tree_sha = tree_resp.json()["sha"]

                commit_resp = requests.post(
                    f"{base_api}/git/commits",
                    headers=headers,
                    json={
                        "message": message,
                        "tree": new_tree_sha,
                        "parents": [head_sha],
                    },
                )
                commit_resp.raise_for_status()
                new_commit_sha = commit_resp.json()["sha"]

                # fast-forward only; 422 means a concurrent writer won the race.
                ref_resp = requests.patch(
                    f"{base_api}/git/refs/heads/{branch}",
                    headers=headers,
                    json={"sha": new_commit_sha, "force": False},
                )
                if ref_resp.status_code == 422:
                    last_error = ref_resp.text
                    time.sleep(0.5)
                    continue
                ref_resp.raise_for_status()

                return {
                    "status": "success",
                    "branch": branch,
                    "branch_link": (
                        f"https://github.com/{_REPO_OWNER}/{_REPO_NAME}/tree/{branch}"
                    ),
                    "message": f"Committed {len(files)} file(s) to '{branch}'.",
                }
            except requests.RequestException as e:
                return {"status": "failure", "message": str(e)}

        return {
            "status": "failure",
            "message": f"Ref update kept conflicting after retries. Last: {last_error}",
        }
