"""Standalone, runnable version of the GitHub Writer tool.

Commits per-case output files (e.g. "5.txt") to a GitHub repo. In the
self-healing design this runs on Workflow 2's PASS path (X >= 80): each passing
case writes its "{caseIndex}.txt" so Workflow 3 can aggregate them.

    python wf_github_writer_run.py

Unlike the sample GithubCommitterTool, this targets ONE stable output branch and
APPENDS each file (auto-creating the branch from base if missing), because the
writer is invoked once per case and must not scatter files across many branches.

Set DRY_RUN = True to print what would be committed instead of calling GitHub.

Kept in sync with wf_github_writer_tool.py (AAVA). The ONLY allowed difference is
credential handling: this file reads GITHUB_TOKEN / repo config from .env / env.
"""

import os
import time
import requests


def _load_dotenv() -> None:
    """Load KEY=VALUE pairs from a .env file next to this script into os.environ.

    Existing environment variables take precedence and are not overwritten.
    """
    env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if not os.path.isfile(env_path):
        return
    with open(env_path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value


_load_dotenv()

# Repo config — override via .env (GITHUB_REPO_OWNER, GITHUB_REPO_NAME, ...).
_REPO_OWNER = os.environ.get("GITHUB_REPO_OWNER", "")
_REPO_NAME = os.environ.get("GITHUB_REPO_NAME", "")
_BASE_BRANCH = os.environ.get("GITHUB_BASE_BRANCH", "main")

# Single stable branch all cases append to, so 1.txt..N.txt land together.
_OUTPUT_BRANCH = os.environ.get("GITHUB_OUTPUT_BRANCH", "self-healing-testcases")

# Retries for the branch ref update, to survive concurrent per-case writers.
_MAX_REF_RETRIES = 5

# When True, prints what would be committed instead of calling GitHub.
DRY_RUN = True


def _get_token() -> str:
    token = os.environ.get("GITHUB_TOKEN", "")
    if not token and not DRY_RUN:
        raise RuntimeError(
            "GITHUB_TOKEN environment variable is not set. "
            "Set it or enable DRY_RUN."
        )
    return token


def _headers(token: str) -> dict:
    return {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json",
        "User-Agent": "Self-Healing-Agent",
    }


def _base_api() -> str:
    return f"https://api.github.com/repos/{_REPO_OWNER}/{_REPO_NAME}"


def _get_branch_sha(base_api: str, branch: str, headers: dict):
    """Return the head commit SHA of a branch, or None if it does not exist."""
    resp = requests.get(f"{base_api}/git/ref/heads/{branch}", headers=headers)
    if resp.status_code == 404:
        return None
    resp.raise_for_status()
    return resp.json()["object"]["sha"]


def _commit_tree_sha(base_api: str, commit_sha: str, headers: dict) -> str:
    resp = requests.get(f"{base_api}/git/commits/{commit_sha}", headers=headers)
    resp.raise_for_status()
    return resp.json()["tree"]["sha"]


def _ensure_branch(base_api: str, branch: str, base_branch: str, headers: dict) -> str:
    """Return the branch head SHA, creating the branch from base if missing."""
    sha = _get_branch_sha(base_api, branch, headers)
    if sha is not None:
        return sha

    base_sha = _get_branch_sha(base_api, base_branch, headers)
    if base_sha is None:
        raise RuntimeError(
            f"Base branch '{base_branch}' not found. Initialize the repo first."
        )
    resp = requests.post(
        f"{base_api}/git/refs",
        headers=headers,
        json={"ref": f"refs/heads/{branch}", "sha": base_sha},
    )
    resp.raise_for_status()
    return base_sha


def commit_files(files: dict, branch: str = None, commit_message: str = None) -> dict:
    """Commit {path: content} files to the output branch, appending to its tree."""
    if not files:
        return {"status": "failure", "message": "No files provided to commit."}

    branch = branch or _OUTPUT_BRANCH
    if not _REPO_OWNER or not _REPO_NAME:
        return {
            "status": "failure",
            "message": "GITHUB_REPO_OWNER / GITHUB_REPO_NAME are not configured.",
        }

    token = _get_token()
    headers = _headers(token)
    base_api = _base_api()

    tree_items = [
        {
            "path": path.lstrip("/"),
            "mode": "100644",
            "type": "blob",
            "content": content,
        }
        for path, content in files.items()
    ]
    message = commit_message or f"self-healing output: {', '.join(files.keys())}"

    if DRY_RUN:
        return {
            "status": "dry_run",
            "message": (
                f"[DRY_RUN] Would commit {len(files)} file(s) "
                f"{list(files.keys())} to branch '{branch}' "
                f"of {_REPO_OWNER}/{_REPO_NAME}."
            ),
        }

    last_error = None
    for _ in range(_MAX_REF_RETRIES):
        try:
            head_sha = _ensure_branch(base_api, branch, _BASE_BRANCH, headers)
            base_tree = _commit_tree_sha(base_api, head_sha, headers)

            tree_resp = requests.post(
                f"{base_api}/git/trees",
                headers=headers,
                json={"base_tree": base_tree, "tree": tree_items},
            )
            tree_resp.raise_for_status()
            new_tree_sha = tree_resp.json()["sha"]

            commit_resp = requests.post(
                f"{base_api}/git/commits",
                headers=headers,
                json={"message": message, "tree": new_tree_sha, "parents": [head_sha]},
            )
            commit_resp.raise_for_status()
            new_commit_sha = commit_resp.json()["sha"]

            # fast-forward only; conflict (422) means a concurrent writer won.
            ref_resp = requests.patch(
                f"{base_api}/git/refs/heads/{branch}",
                headers=headers,
                json={"sha": new_commit_sha, "force": False},
            )
            if ref_resp.status_code == 422:
                last_error = ref_resp.text
                time.sleep(0.5)
                continue
            ref_resp.raise_for_status()

            return {
                "status": "success",
                "branch": branch,
                "branch_link": (
                    f"https://github.com/{_REPO_OWNER}/{_REPO_NAME}/tree/{branch}"
                ),
                "message": f"Committed {len(files)} file(s) to '{branch}'.",
            }
        except requests.RequestException as e:
            return {"status": "failure", "message": str(e)}

    return {
        "status": "failure",
        "message": f"Ref update kept conflicting after retries. Last: {last_error}",
    }


def main() -> None:
    # Standalone harness only: simulate one passing case writing its N.txt.
    case_index = 5
    content = "TC_001 | ... approved test cases for this case ...\n"
    print(commit_files({f"{case_index}.txt": content}))


if __name__ == "__main__":
    main()
