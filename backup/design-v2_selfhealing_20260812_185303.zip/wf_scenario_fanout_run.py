"""Standalone, runnable version of the Scenario Fan-Out tool.

Splits a scenario array (from the Scenario Gen agent) and triggers Workflow 2
(pipeline 163) once per scenario, seeding caseIndex and attempt=1 so the
downstream circuit breaker can bound the self-healing loop.

    python wf_scenario_fanout_run.py

Set DRY_RUN = True to print each outgoing payload instead of calling the API.

Kept in sync with wf_scenario_fanout_tool.py (AAVA). The ONLY allowed
difference is PAT handling: this file reads AAVA_TOKEN from .env / env.
"""

import json
import os
import requests


def _load_dotenv() -> None:
    """Load KEY=VALUE pairs from a .env file next to this script into os.environ.

    Existing environment variables take precedence and are not overwritten.
    """
    env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if not os.path.isfile(env_path):
        return
    with open(env_path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value


_load_dotenv()

# Target pipeline for Workflow 2 (testcase gen + reviewer + circuit breaker).
_WORKFLOW2_PIPELINE_ID = 176

# Priority is always hardcoded; it is not received from the agent.
_PRIORITY = 1

# Every scenario starts its self-healing loop at attempt 1.
_INITIAL_ATTEMPT = 1

# When True, prints the normalized payloads instead of making the HTTP calls.
DRY_RUN = False

_API_URL = (
    "https://aava-core-api-workflows-svc.redtree-f4541a84.eastus."
    "azurecontainerapps.io/workflows/workflow-executions"
)


def _get_pat_token() -> str:
    """Read the PAT token from the environment (AAVA_TOKEN)."""
    token = os.environ.get("AAVA_TOKEN", "")
    if not token and not DRY_RUN:
        raise RuntimeError(
            "AAVA_TOKEN environment variable is not set. "
            "Set it or enable DRY_RUN."
        )
    return token


def _normalize_form_data(data: dict) -> dict:
    """Normalize all values to strings for multipart form-data encoding.

    Nested dicts/lists are JSON-serialized.
    """
    normalized = {}
    for key, value in data.items():
        if isinstance(value, (dict, list)):
            normalized[key] = json.dumps(value)
        elif value is None:
            normalized[key] = ""
        else:
            normalized[key] = str(value)
    return normalized


def _coerce_scenarios(scenariojson):
    """Return a list of scenario objects from a JSON string, dict, or list."""
    if isinstance(scenariojson, str):
        scenariojson = json.loads(scenariojson)
    if isinstance(scenariojson, dict):
        scenariojson = [scenariojson]
    if not isinstance(scenariojson, list):
        raise ValueError("scenariojson must be a JSON array of scenario objects")
    return scenariojson


def fan_out_scenarios(scenariojson) -> str:
    """Split the scenario array and trigger Workflow 2 once per scenario."""
    try:
        scenarios = _coerce_scenarios(scenariojson)
    except (ValueError, json.JSONDecodeError) as e:
        return f"Error: could not parse scenariojson: {e}"

    if not scenarios:
        return "Error: scenariojson is empty; nothing to fan out."

    pat_token = _get_pat_token()
    headers = {"Authorization": f"Bearer {pat_token}"}

    results = []
    for index, scenario in enumerate(scenarios, start=1):
        scenario_id = scenario.get("scenarioId", "") if isinstance(scenario, dict) else ""

        form_data = {
            "pipelineId": _WORKFLOW2_PIPELINE_ID,
            "priority": _PRIORITY,
            "userInputs": {
                # One scenario per call, wrapped as a single-element array so
                # the testcase-gen agent still receives an array of scenarios.
                "tsInputJson_string_true": json.dumps([scenario]),
                "rvwFeedbackTxt_string_false": "",
                "caseIndex": index,
                "attempt": _INITIAL_ATTEMPT,
            },
        }

        normalized = _normalize_form_data(form_data)

        if DRY_RUN:
            results.append(
                f"[DRY_RUN] case {index} ({scenario_id}) -> would POST to "
                f"{_API_URL}\nPayload:\n{json.dumps(normalized, indent=2)}"
            )
            continue

        try:
            response = requests.post(
                _API_URL,
                files={k: (None, v) for k, v in normalized.items()},
                headers=headers,
            )
            response.raise_for_status()
            try:
                body = response.json()
            except Exception:
                body = response.text
            results.append(f"case {index} ({scenario_id}): triggered -> {body}")
        except requests.RequestException as e:
            results.append(f"case {index} ({scenario_id}): ERROR -> {str(e)}")

    header = (
        f"Fan-out complete: {len(scenarios)} scenario(s) -> "
        f"pipeline {_WORKFLOW2_PIPELINE_ID}."
    )
    return header + "\n" + "\n".join(results)


def main() -> None:
    # Standalone harness only: load the scenario-gen output from disk. The AAVA
    # tool never reads a file — it receives scenariojson from the previous agent.
    scenarios_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "scenarios.json"
    )
    with open(scenarios_path, "r", encoding="utf-8") as fh:
        scenariojson = json.load(fh)

    print(fan_out_scenarios(scenariojson))


if __name__ == "__main__":
    main()
