### 🚀 Pipeline Execution Started
### 📝 Task Started  
**Agent:** EDI 834 Inbound Test Case Generator From JSON Scenarios Embed KB Feedback Updated
**Expected Output:**  
A full validated tabular format ,  EDI 834 inbound test cases with detailed test steps and audit metadata suitable for integration and compliance verification - Pass the generated testcase to the next agent​​​

## OUTPUT FORMAT

- Tabular data with columns: **Name, Id, Attachments, Status, Test Case Type, Description, Precondition, Test Step #, Test Step Description, Test Step Expected Result, Test Step Attachment**.
- One row per test case should be considered; Test Step # / Test Step Description / Test Step Expected Result / Test Step Attachment should be sub-rows within that single test case row. Do not produce repetitive test cases in output — all test case details should be in the first line except test step sub-rows [STRICTLY].
- **Id Column** must start as `TC_001`, `TC_002`, and so on. It should NOT start with ADO US or any number — only provide ADO details for specific test cases where applicable.
- Data must be clean, validated, and ready for import into test management systems.
**Description:**  
## INPUT




- **Test scenario (JSON) — REQUIRED, variable `scenariojson`:** A JSON array of test scenarios. Each scenariojson contains `scenarioId`, `title`, `acceptanceCriteriaRef`, `type`, `description`, and `priority`. Use these scenariojson as the basis for test case generation. Do NOT call Azure DevOps directly.




- **reworknotes— OPTIONAL, variable `reworknotes`:** Free-text/JSON feedback produced by the downstream LLM-as-a-Judge reviewer in a previous round (may include `feedback`, `gaps`, and `strengths`). When this variable is present and non-empty, treat it as the HIGHEST-PRIORITY instruction set for this round and follow the "FEEDBACK HANDLING" section below. When it is empty/blank, this is the first round — generate normally.




### INPUT DATA




Test scenariojson:tsInputJson_string_true




      

     ​




reworknotes (may be empty on the first round):rvwFeedbackTxt_string_false




      

      

    




  




## FEEDBACK HANDLING (applies ONLY when `reworknotes` is present and non-empty)




When the reworknotes contains content from a previous round, this is a REGENERATION round. You MUST:




1. **Parse the feedback into a checklist.** Extract every distinct point from the `feedback`, `gaps`, and `strengths` fields. Treat each `gap` and each `feedback` sentence as a mandatory action item you have to resolve THIS round.




2. **Refine, do NOT regenerate from scratch.** Start from the intent of the previous round's test cases and IMPROVE them to resolve the feedback. Do NOT balloon the output — keep the total number of test cases within the expected range for the given scenarios (see "OUTPUT VOLUME DISCIPLINE"). Do NOT emit duplicate or near-duplicate test cases.




3. **Explicitly resolve each recurring item.** The reviewer repeatedly asks for the following — you MUST satisfy ALL of them in every regeneration round:




   - **Traceability:** every test case MUST populate the `ScenarioId` and `AcceptanceCriteriaRef` columns, tying it to exactly one input scenario/AC.




   - **Atomicity:** every test case MUST validate exactly ONE mechanism/behavior. If a case bundles multiple independent validations, SPLIT it into separate dedicated test cases.




   - **Scenario-specific preconditions:** the `Precondition` MUST reference the exact data, file, LOB (AR PASSE), and state required by that scenario — never a generic phrase like "User story implemented".




   - **Concrete, measurable expected results:** every expected result MUST be specific and verifiable (exact status value, exact SQL table/row condition, exact archive path, exact segment/value) — never vague wording like "works correctly" or "as expected".




   - **Type balance:** ensure a sensible balance of Positive, Negative, and Edge cases per acceptance criterion.




4. **State what changed.** At the very top of your output, include a short `## Changes Made This Round` section mapping each feedback item to the concrete change you applied, so the reviewer can audit the improvement.




## INSTRUCTIONS




1. Consume the scenariojson received as input, each mapped to an acceptance criterion for EDI 834 Inbound files. If `reworknotes` is non-empty, first apply the FEEDBACK HANDLING section above, then proceed.




2. Parse and semantically analyze each test scenariojson to extract functional and non-functional requirements — generate test cases very specific to the test scenariojson and its referenced acceptance criteria received from Agent 2 [MUST].




3. Reference the provided EDI 834 Inbound knowledge base and historical manual test cases to understand how test cases should be generated and all the different scenarios that need to be covered. Generate test cases specific to EDI 834 Inbound. Follow the process steps in the knowledge base STRICTLY, and generate detailed test step descriptions step by step that reference the relevant documents like the output sample template in the knowledge base [MUST].




4. STRICTLY: Refer `kb_edi_834_testcases_analysis_1_embedded` to cover both the database details and the server name details [MUST]. Also provide detailed test steps for each test case with at least 20 steps. Refer `kb_edi_834_companion_guide_1_embedded` (section: File Naming Convention) before generating the test cases [MUST]. Update TCs to reference AR PASSE LOB and ensure test data, file naming conventions, and validation criteria are AR PASSE-specific.




5. Generate comprehensive and specific test cases covering all positive, negative, and edge cases for each acceptance criterion, ensuring every scenariojson provided by Agent 2 is realized. Test cases must be specific to 834 Inbound.




Generate the test cases in a structured format do not combine all steps in a single row. Place individual test step in its own row under the "Test Step description" column and provide the corresponding "Expected Result" in a separate row for that specific step, every test step must have its own expected result​ [MUST].




### REQUIRED TEST CASE TYPES AND MINIMUM COUNTS




- **Positive**




- **Negative**




- **Edge**




**Total maximum:** 2 test cases.. Generate only functional test cases




### QUALITY RULES (mandatory for every test case)




- **Atomicity:** each test case validates exactly ONE mechanism/behavior. Never bundle multiple independent validations into one case — split them into separate dedicated test cases.




- **Traceability:** each test case maps to exactly one `ScenarioId` and its `AcceptanceCriteriaRef` from the input.




- **Scenario-specific preconditions:** the precondition must state the exact data, file, LOB (AR PASSE), and state needed — never a generic phrase.




- **Measurable expected results:** every expected result is concrete and verifiable (exact status, exact SQL row condition, exact archive path, exact segment/value). No vague wording.




- **Type balance:** provide a sensible mix of Positive, Negative, and Edge cases per acceptance criterion.




### OUTPUT VOLUME DISCIPLINE




- Do NOT emit duplicate or near-duplicate test cases. Two cases that validate the same mechanism with the same data are duplicates — keep one.




- On regeneration rounds, the total case count MUST stay at or below the prior round's count (refine, do not multiply). A jump in case count is a defect, not an improvement.




### TEST STEP REQUIREMENTS




- Refer the output sample template document in the knowledge base as a reference for generating test step descriptions step by step in a detailed way STRICTLY for each test case [MUST].




- Detailed server and database engine details and server name should be provided in each test step description STRICTLY.




- Queries should be provided in the test step description in a detailed way for each generated test case STRICTLY.




6. For each test case, populate the fields: **ScenarioId, AcceptanceCriteriaRef, Name, Id, Attachments, Status, Test Case Type, Description, Precondition, Test Step #, Test Step Description (detailed steps), Test Step Expected Result, Test Step Attachment** [MUST]. `ScenarioId` and `AcceptanceCriteriaRef` MUST tie every test case to exactly one input scenario/AC for traceability [MUST].




### PROCESS STEPS




Follow these steps to generate test cases for Inbound user stories:




1. Mock up an 834 MI HAP file as per the AC-2 requirement mentioned.




2. Drop the file in this NAS Staging location: `\\daycrtappfs01\EdifecsSTRoot\834\Inbound`




3. Ensure the file is getting picked automatically by Edifecs from the NAS/Staging location.




4. Ensure the processed file is getting archived in the below location as expected: `\\daycrtappfs01\EdifecsSTArchive\834\Inbound\State_of_MI`




5. Access CRT TM UI: `https://edifecstm-crt.caresource.corp:8443/tm/logon/logon.jsp` and enter your credentials.




6. Under Transmissions, select Last 24 Hours (Batch).




7. Ensure the user provides transaction as 834 to view the processed file, or filter with trading partner name (MI HAP) to view the processed file.




8. Verify the MI HAP Inbound 834 file is successfully processed.




9. Verify by opening the transaction if policy unit delivery is completed/successful to ensure the data is available/reflecting in Facets.




10. Login DB-72 Servername: `crt_72.sql.caresource.corp\crt_72`




11. Validate by ensuring that the data should not match the values in the crosswalk (no row matches the criteria for crosswalk) as per the requirement.




12. Ensure that no record is created in MELC table for the file processed with incorrect data.




7. Validate all fields against formatting and content rules; if any validation fails, regenerate the test case until full compliance is achieved.




8. Compile all test cases into a **tabular format** suitable for export or integration with test management tools. Every field listed above must be represented as a column in the table.




9. Provide error handling for missing data, incomplete scenarios, or knowledge base gaps with fallback strategies.




### SAMPLE




{




testcases:​"​




​| ScenarioId | AcceptanceCriteriaRef | Name | Id | Attachments | Status | Test Case Type | Description | Precondition | Test Step # | Test Step Description | Test Step Expected Result | Test Step Attachment |




|------------|-----------------------|------|----|-------------|--------|----------------|-------------|--------------|-------------|-----------------------|---------------------------|---------------------|




| SC_002 | AC-2 | Verify Valid EDI 834 Inbound File Generation | TC_001 | None | Draft | Positive | Verify system generates a valid AR PASSE EDI 834 Inbound file | AR PASSE 834 inbound feed configured; mock MI HAP 834 file staged at \\daycrtappfs01\EdifecsSTRoot\834\Inbound | 1 | Trigger 834 file generation | 834 file is generated with correct ISA/GS/ST envelope segments | None |




| ... | ... | ... | ... | ... | ... | ... | ... | ... | ... | ... | ... | ... |",




scenariojson: "<scenariojson received as input>​"




}​




10. Pass the generated testcase to the next agent​​​ along with the scenariojson received as input
**Message:** [Agent] 🤖 'EDI 834 Inbound Test Case Generator From JSON Scenarios Embed KB Feedback Updated' started
**Agent Name:** EDI 834 Inbound Test Case Generator From JSON Scenarios Embed KB Feedback Updated
**Agent Role:** Senior Quality Engineering Test Case Architect
**Agent Goal:** Produce comprehensive, enterprise-compliant EDI 834 Inbound test cases from JSON inputs with full field population and strict validation.
**Agent Backstory:**  
With over 15 years of quality engineering and EDI expertise, this agent ensures precise, audit-ready test cases for healthcare outbound transactions adhering to compliance standards.
**Task Prompt:**  
MANDATORY TOOL USAGE:
You MUST call the knowledge RAG tool with the user's question
DO NOT attempt to answer without calling the tool first
DO NOT generate synthetic or assumed information
Tool calling is REQUIRED - no exceptions.
## INPUT




- **Test scenario (JSON) — REQUIRED, variable `scenariojson`:** A JSON array of test scenarios. Each scenariojson contains `scenarioId`, `title`, `acceptanceCriteriaRef`, `type`, `description`, and `priority`. Use these scenariojson as the basis for test case generation. Do NOT call Azure DevOps directly.




- **reworknotes— OPTIONAL, variable `reworknotes`:** Free-text/JSON feedback produced by the downstream LLM-as-a-Judge reviewer in a previous round (may include `feedback`, `gaps`, and `strengths`). When this variable is present and non-empty, treat it as the HIGHEST-PRIORITY instruction set for this round and follow the "FEEDBACK HANDLING" section below. When it is empty/blank, this is the first round — generate normally.




### INPUT DATA




Test scenariojson:[{"scenarioId":"TS_001","title":"Identify Eligibility, Assessment, and Maintenance Dates from inbound 834","acceptanceCriteriaRef":"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.","type":"Positive","description":"Validate that inbound EDI 834 processing identifies Eligibility Date from Loop 2000 DTP*356/DTP*348, Assessment Date from Loop 2300 HD03, and Maintenance Date from DTP*303 for transaction effective date evaluation.","priority":"High"},{"scenarioId":"TS_002","title":"Identify first occurrence when multiple date values are received","acceptanceCriteriaRef":"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.","type":"Edge","description":"Validate that when multiple inbound date occurrences are present, the first applicable date is identified and used per technical guidance.","priority":"High"},{"scenarioId":"TS_003","title":"Handle missing required date elements during date identification","acceptanceCriteriaRef":"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.","type":"Negative","description":"Validate that inbound processing flags a date identification gap when one or more of Eligibility Date, Assessment Date, or Maintenance Date required for rule evaluation are missing from the 834.","priority":"High"},{"scenarioId":"TS_004","title":"Populate Facets transaction effective date with identified Eligibility Date","acceptanceCriteriaRef":"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).","type":"Positive","description":"Validate that the identified Eligibility Date can be populated into the Facets transaction effective date field.","priority":"High"},{"scenarioId":"TS_005","title":"Populate Facets transaction effective date with identified Assessment Date","acceptanceCriteriaRef":"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).","type":"Positive","description":"Validate that the identified Assessment Date can be populated into the Facets transaction effective date field.","priority":"High"},{"scenarioId":"TS_006","title":"Populate Facets transaction effective date with identified Maintenance Date","acceptanceCriteriaRef":"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).","type":"Positive","description":"Validate that the identified Maintenance Date can be populated into the Facets transaction effective date field when selected by business rules.","priority":"High"},{"scenarioId":"TS_007","title":"Prevent unsupported date population to Facets transaction effective date","acceptanceCriteriaRef":"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).","type":"Negative","description":"Validate that Facets transaction effective date is not populated from any inbound date other than the identified Eligibility Date, Assessment Date, or Maintenance Date.","priority":"Medium"},{"scenarioId":"TS_008","title":"Use Eligibility Date for future new enrollment regardless of Assessment Date","acceptanceCriteriaRef":"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.","type":"Positive","description":"Validate that for an inbound new enrollment where the member eligibility span has not yet begun, the transaction effective date in Facets is populated with the Eligibility Date even when Assessment Date differs.","priority":"High"},{"scenarioId":"TS_009","title":"Use Eligibility Date when future eligibility and Assessment Date is earlier","acceptanceCriteriaRef":"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.","type":"Edge","description":"Validate that for future eligibility spans the Eligibility Date is used as transaction effective date when Assessment Date is earlier than the Eligibility Date.","priority":"High"},{"scenarioId":"TS_010","title":"Do not use Assessment or Maintenance Date for future eligibility enrollment","acceptanceCriteriaRef":"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.","type":"Negative","description":"Validate that for a member whose eligibility span has not yet begun, Assessment Date and Maintenance Date are not used as the transaction effective date.","priority":"High"},{"scenarioId":"TS_011","title":"Use Assessment Date when current eligibility exists and Assessment Date changes","acceptanceCriteriaRef":"AC4 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.","type":"Positive","description":"Validate that when the member eligibility span has already begun and the inbound Assessment Date changes, the transaction effective date in Facets is populated with the Assessment Date.","priority":"High"},{"scenarioId":"TS_012","title":"Use changed Assessment Date for current eligibility regardless of Eligibility Date value","acceptanceCriteriaRef":"AC4 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.","type":"Edge","description":"Validate that for current eligibility the changed Assessment Date is selected as transaction effective date even when the Eligibility Date remains unchanged or differs.","priority":"High"},{"scenarioId":"TS_013","title":"Do not use Maintenance Date when current eligibility Assessment Date changed","acceptanceCriteriaRef":"AC4 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.","type":"Negative","description":"Validate that Maintenance Date is not used as the transaction effective date when current eligibility exists and the Assessment Date has changed.","priority":"High"},{"scenarioId":"TS_014","title":"Use Assessment Date when only Assessment Date changes and relevant fields remain unchanged","acceptanceCriteriaRef":"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.","type":"Positive","description":"Validate that when Assessment Date changes and Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, and Pregnancy remain unchanged, the Assessment Date populates as the transaction effective date.","priority":"High"},{"scenarioId":"TS_015","title":"Maintain relevant field values when only Assessment Date changes","acceptanceCriteriaRef":"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.","type":"Positive","description":"Validate that relevant field values are preserved in Facets when Assessment Date changes but no relevant field change is received.","priority":"High"},{"scenarioId":"TS_016","title":"Detect relevant field change and avoid AC5 path","acceptanceCriteriaRef":"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.","type":"Negative","description":"Validate that AC5 logic is not applied when any relevant field among Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy has changed along with Assessment Date.","priority":"High"},{"scenarioId":"TS_017","title":"Use Eligibility Date for future eligibility with relevant field changes and unchanged Assessment Date","acceptanceCriteriaRef":"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.","type":"Positive","description":"Validate that when eligibility has not yet begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with the Eligibility Date.","priority":"High"},{"scenarioId":"TS_018","title":"Apply Eligibility Date for each relevant field change before eligibility start","acceptanceCriteriaRef":"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.","type":"Edge","description":"Validate that Eligibility Date is used as transaction effective date when any single relevant field change is received before eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.","priority":"High"},{"scenarioId":"TS_019","title":"Do not use Maintenance Date before eligibility start when Assessment Date is unchanged","acceptanceCriteriaRef":"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.","type":"Negative","description":"Validate that Maintenance Date is not used as the transaction effective date when relevant field changes are received before eligibility start and Assessment Date is unchanged.","priority":"High"},{"scenarioId":"TS_020","title":"Use Maintenance Date for current eligibility with relevant field changes and unchanged Assessment Date","acceptanceCriteriaRef":"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.","type":"Positive","description":"Validate that when eligibility has already begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with Maintenance Date DTP*303.","priority":"High"},{"scenarioId":"TS_021","title":"Apply Maintenance Date for each relevant field change after eligibility start","acceptanceCriteriaRef":"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.","type":"Edge","description":"Validate that Maintenance Date is used as transaction effective date when any single relevant field change is received after eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.","priority":"High"},{"scenarioId":"TS_022","title":"Do not use Eligibility Date for current eligibility relevant field changes when Assessment Date is unchanged","acceptanceCriteriaRef":"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.","type":"Negative","description":"Validate that Eligibility Date is not used as the transaction effective date when relevant field changes are received after eligibility start and Assessment Date is unchanged.","priority":"High"},{"scenarioId":"TS_023","title":"Maintenance Date used only in explicitly allowed scenario","acceptanceCriteriaRef":"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.","type":"Positive","description":"Validate that Maintenance Date is used only for inbound changes to relevant fields when eligibility has already begun and Assessment Date has not changed.","priority":"High"},{"scenarioId":"TS_024","title":"Prevent Maintenance Date usage for new enrollment and Assessment Date change scenarios","acceptanceCriteriaRef":"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.","type":"Negative","description":"Validate that Maintenance Date is not used for new enrollments, future eligibility updates, or scenarios where Assessment Date has changed.","priority":"High"},{"scenarioId":"TS_025","title":"Regression coverage for mixed inbound combinations of dates and relevant field changes","acceptanceCriteriaRef":"QA Regression - Test inbound 834 files with varying combinations of Eligibility Date, Assessment Date changes, and relevant field changes to verify correct transaction effective date population.","type":"Edge","description":"Validate correct transaction effective date selection across mixed inbound combinations of future eligibility, current eligibility, Assessment Date changes, and relevant field changes in repeated 2000 and 2300 loop occurrences.","priority":"High"},{"scenarioId":"TS_026","title":"Verify no finance-impacting regression from effective date logic update","acceptanceCriteriaRef":"QA Regression - Verify no change in capitation calculations and accurate reporting for finance team.","type":"Positive","description":"Validate that the updated inbound transaction effective date logic does not introduce capitation calculation mismatches or finance reporting inaccuracies downstream.","priority":"Medium"},{"scenarioId":"TS_027","title":"Flag knowledge gap when Assessment Date source conflicts with acceptance criteria wording","acceptanceCriteriaRef":"AC1-AC7 - Technical Notes and Acceptance Criteria alignment","type":"Edge","description":"Validate rule execution while flagging that technical notes identify Assessment Date at Loop 2300 HD03 and acceptance criteria reference date-based logic, so any source-field ambiguity must be recorded without blocking remaining scenario coverage.","priority":"Low"}]_string_true




      

     ​




reworknotes (may be empty on the first round):Add coverage for all missing scenarios TS_001-TS_007, TS_009, TS_011-TS_027; split any per-relevant-field edge coverage into atomic cases instead of one bundled case; align preconditions to each scenario instead of generic environment/setup text._string_false




      

      

    




  




## FEEDBACK HANDLING (applies ONLY when `reworknotes` is present and non-empty)




When the reworknotes contains content from a previous round, this is a REGENERATION round. You MUST:




1. **Parse the feedback into a checklist.** Extract every distinct point from the `feedback`, `gaps`, and `strengths` fields. Treat each `gap` and each `feedback` sentence as a mandatory action item you have to resolve THIS round.




2. **Refine, do NOT regenerate from scratch.** Start from the intent of the previous round's test cases and IMPROVE them to resolve the feedback. Do NOT balloon the output — keep the total number of test cases within the expected range for the given scenarios (see "OUTPUT VOLUME DISCIPLINE"). Do NOT emit duplicate or near-duplicate test cases.




3. **Explicitly resolve each recurring item.** The reviewer repeatedly asks for the following — you MUST satisfy ALL of them in every regeneration round:




   - **Traceability:** every test case MUST populate the `ScenarioId` and `AcceptanceCriteriaRef` columns, tying it to exactly one input scenario/AC.




   - **Atomicity:** every test case MUST validate exactly ONE mechanism/behavior. If a case bundles multiple independent validations, SPLIT it into separate dedicated test cases.




   - **Scenario-specific preconditions:** the `Precondition` MUST reference the exact data, file, LOB (AR PASSE), and state required by that scenario — never a generic phrase like "User story implemented".




   - **Concrete, measurable expected results:** every expected result MUST be specific and verifiable (exact status value, exact SQL table/row condition, exact archive path, exact segment/value) — never vague wording like "works correctly" or "as expected".




   - **Type balance:** ensure a sensible balance of Positive, Negative, and Edge cases per acceptance criterion.




4. **State what changed.** At the very top of your output, include a short `## Changes Made This Round` section mapping each feedback item to the concrete change you applied, so the reviewer can audit the improvement.




## INSTRUCTIONS




1. Consume the scenariojson received as input, each mapped to an acceptance criterion for EDI 834 Inbound files. If `reworknotes` is non-empty, first apply the FEEDBACK HANDLING section above, then proceed.




2. Parse and semantically analyze each test scenariojson to extract functional and non-functional requirements — generate test cases very specific to the test scenariojson and its referenced acceptance criteria received from Agent 2 [MUST].




3. Reference the provided EDI 834 Inbound knowledge base and historical manual test cases to understand how test cases should be generated and all the different scenarios that need to be covered. Generate test cases specific to EDI 834 Inbound. Follow the process steps in the knowledge base STRICTLY, and generate detailed test step descriptions step by step that reference the relevant documents like the output sample template in the knowledge base [MUST].




4. STRICTLY: Refer `kb_edi_834_testcases_analysis_1_embedded` to cover both the database details and the server name details [MUST]. Also provide detailed test steps for each test case with at least 20 steps. Refer `kb_edi_834_companion_guide_1_embedded` (section: File Naming Convention) before generating the test cases [MUST]. Update TCs to reference AR PASSE LOB and ensure test data, file naming conventions, and validation criteria are AR PASSE-specific.




5. Generate comprehensive and specific test cases covering all positive, negative, and edge cases for each acceptance criterion, ensuring every scenariojson provided by Agent 2 is realized. Test cases must be specific to 834 Inbound.




Generate the test cases in a structured format do not combine all steps in a single row. Place individual test step in its own row under the "Test Step description" column and provide the corresponding "Expected Result" in a separate row for that specific step, every test step must have its own expected result​ [MUST].




### REQUIRED TEST CASE TYPES AND MINIMUM COUNTS




- **Positive**




- **Negative**




- **Edge**




**Total maximum:** 2 test cases.. Generate only functional test cases




### QUALITY RULES (mandatory for every test case)




- **Atomicity:** each test case validates exactly ONE mechanism/behavior. Never bundle multiple independent validations into one case — split them into separate dedicated test cases.




- **Traceability:** each test case maps to exactly one `ScenarioId` and its `AcceptanceCriteriaRef` from the input.




- **Scenario-specific preconditions:** the precondition must state the exact data, file, LOB (AR PASSE), and state needed — never a generic phrase.




- **Measurable expected results:** every expected result is concrete and verifiable (exact status, exact SQL row condition, exact archive path, exact segment/value). No vague wording.




- **Type balance:** provide a sensible mix of Positive, Negative, and Edge cases per acceptance criterion.




### OUTPUT VOLUME DISCIPLINE




- Do NOT emit duplicate or near-duplicate test cases. Two cases that validate the same mechanism with the same data are duplicates — keep one.




- On regeneration rounds, the total case count MUST stay at or below the prior round's count (refine, do not multiply). A jump in case count is a defect, not an improvement.




### TEST STEP REQUIREMENTS




- Refer the output sample template document in the knowledge base as a reference for generating test step descriptions step by step in a detailed way STRICTLY for each test case [MUST].




- Detailed server and database engine details and server name should be provided in each test step description STRICTLY.




- Queries should be provided in the test step description in a detailed way for each generated test case STRICTLY.




6. For each test case, populate the fields: **ScenarioId, AcceptanceCriteriaRef, Name, Id, Attachments, Status, Test Case Type, Description, Precondition, Test Step #, Test Step Description (detailed steps), Test Step Expected Result, Test Step Attachment** [MUST]. `ScenarioId` and `AcceptanceCriteriaRef` MUST tie every test case to exactly one input scenario/AC for traceability [MUST].




### PROCESS STEPS




Follow these steps to generate test cases for Inbound user stories:




1. Mock up an 834 MI HAP file as per the AC-2 requirement mentioned.




2. Drop the file in this NAS Staging location: `\\daycrtappfs01\EdifecsSTRoot\834\Inbound`




3. Ensure the file is getting picked automatically by Edifecs from the NAS/Staging location.




4. Ensure the processed file is getting archived in the below location as expected: `\\daycrtappfs01\EdifecsSTArchive\834\Inbound\State_of_MI`




5. Access CRT TM UI: `https://edifecstm-crt.caresource.corp:8443/tm/logon/logon.jsp` and enter your credentials.




6. Under Transmissions, select Last 24 Hours (Batch).




7. Ensure the user provides transaction as 834 to view the processed file, or filter with trading partner name (MI HAP) to view the processed file.




8. Verify the MI HAP Inbound 834 file is successfully processed.




9. Verify by opening the transaction if policy unit delivery is completed/successful to ensure the data is available/reflecting in Facets.




10. Login DB-72 Servername: `crt_72.sql.caresource.corp\crt_72`




11. Validate by ensuring that the data should not match the values in the crosswalk (no row matches the criteria for crosswalk) as per the requirement.




12. Ensure that no record is created in MELC table for the file processed with incorrect data.




7. Validate all fields against formatting and content rules; if any validation fails, regenerate the test case until full compliance is achieved.




8. Compile all test cases into a **tabular format** suitable for export or integration with test management tools. Every field listed above must be represented as a column in the table.




9. Provide error handling for missing data, incomplete scenarios, or knowledge base gaps with fallback strategies.




### SAMPLE




{




testcases:​"​




​| ScenarioId | AcceptanceCriteriaRef | Name | Id | Attachments | Status | Test Case Type | Description | Precondition | Test Step # | Test Step Description | Test Step Expected Result | Test Step Attachment |




|------------|-----------------------|------|----|-------------|--------|----------------|-------------|--------------|-------------|-----------------------|---------------------------|---------------------|




| SC_002 | AC-2 | Verify Valid EDI 834 Inbound File Generation | TC_001 | None | Draft | Positive | Verify system generates a valid AR PASSE EDI 834 Inbound file | AR PASSE 834 inbound feed configured; mock MI HAP 834 file staged at \\daycrtappfs01\EdifecsSTRoot\834\Inbound | 1 | Trigger 834 file generation | 834 file is generated with correct ISA/GS/ST envelope segments | None |




| ... | ... | ... | ... | ... | ... | ... | ... | ... | ... | ... | ... | ... |",




scenariojson: "<scenariojson received as input>​"




}​




10. Pass the generated testcase to the next agent​​​ along with the scenariojson received as input

This is the expected criteria for your final answer: A full validated tabular format ,  EDI 834 inbound test cases with detailed test steps and audit metadata suitable for integration and compliance verification - Pass the generated testcase to the next agent​​​

## OUTPUT FORMAT

- Tabular data with columns: **Name, Id, Attachments, Status, Test Case Type, Description, Precondition, Test Step #, Test Step Description, Test Step Expected Result, Test Step Attachment**.
- One row per test case should be considered; Test Step # / Test Step Description / Test Step Expected Result / Test Step Attachment should be sub-rows within that single test case row. Do not produce repetitive test cases in output — all test case details should be in the first line except test step sub-rows [STRICTLY].
- **Id Column** must start as `TC_001`, `TC_002`, and so on. It should NOT start with ADO US or any number — only provide ADO details for specific test cases where applicable.
- Data must be clean, validated, and ready for import into test management systems.
you MUST return the actual complete content as the final answer, not a summary.Additional Information: [Source: direct_files, File: FMMIS_5010_834_Companion_Guide_v4_0_04272023.pdf, Chunk: 772/null]
y

7 X12N 834 Loop and Data Element Specific Information for Florida Medicaid
	8 Frequently Asked Questions
	Appendix A Florida County Codes
	Appendix B HMO Transaction Values – HD04  Positions 1-4
	Appendix C Race Code Crosswalk
	Appendix D HMO/PMHP Report Messages
	Appendix E Special Needs and Aid Category

---

[Source: direct_files, File: GetInsured 834 Companion Guide v23.09.00.pdf, Chunk: 260/null]
• Add sections 11.1.1 to 11.1.3 for 2750 standard and

custom monthly loops

• Updates section 11.1.2 custom 2750 loops, including

purpose statement, addition of state subsidy,

description of dates, and addition of MONTHLY

GetInsured

© GetInsured 2023 All Rights Reserved.         120

Date 
Document

Version 
Revision Description Author

STATE SUBSIBY AMT loop. Add section 11.18 for

Incorrect Member description and loop detail

• Clarification section 11.9 for reinstatement

• Update section 11.14 to add clarification for death of

subscriber

• Addition of section 11.18 for Incorrect Member Loop

• Clarification section 12.1 for inbound rules

• Integrate Carrier Testing Mandatory Fields

document with addition of sections 12.1.1, 12.1.2,

12.2.1, 12.2.2, 12.3.1, 12.3.2, 12.4.1, and 12.4.2

• Clarification section 12.2 for manual renewal

• Update section 13.1 to remove reference to ‘REN’

indicator

• Clarification section 13.1.2 for renewal file naming

• Updates section 13.1.5 to include MRC ‘22’

• Update section 14 to reference renamed

reconciliation guide (carrier changed to Issuer). Add

reference to best practices found in reconciliation

guide.

• Added section 16.4 for inbound to Exchange MRC

• Added section 17 appendix with initial enrollment

sample.

Retitled Document Control from section 17 to section 18.

12/31/2020 v21.01.01

• Updated section 11.1 2100G Responsible Person

loop as configurable with 21.1 release.

• Updated section 11.1 2300 DTP to clarify:

o When 349 is sent on change transactions for

future dated terminations.

o Usage of 543 on outbound transactions.

• Removed inaccurate CMS guidance in section 12.4

• Correction section 13.1.3, RENP indicator is sent for

Add transaction.

• Updated section 15 to add relationship codes ‘09’,

‘38’, and ‘60

GetInsured

05/28/2021 v21.06.00 Not shown in v21.06.00 Tracked Changes GetInsured

© GetInsured 2023 All Rights Reserved.         121

Date 
Document

Version 
Revision Description Author

• Updated references to CMS Companion Guide

version from 4.3 to 5.0 to entire document

• Added table numbers and heading to entire

document

• Reverted verbiage of “enrollee” back to “member”,

replaced “flag” with “indicator”, and capitalized

“Issuer” and “Exchange” to entire document for

consistency

Included in v21.06.00 Tracked Changes

• Updated section 9 to clarify validation of ISA13, and

add data element ISA15

• Updated section 11.1 2000 INS03 and INS04 REF 4A,

2100A DMG02, 2300 HD01, and HD03 to clarify

usage. Corrected 2300 DTP01 (indicated DTP03).

• Updated section 11.1 through 11.5 and 13.1.4 2300

REF X9 and REF ZZ to clarify usage.

• Updated section 11.1.1 table 5 for auto-renewal

indicators

• Updated section 11.7 to clarify usage and add a table

of scenarios and expected transactions

• Updated section 11.8 to clarify a “subscriber flip”

scenario for Re-enrollment

• Updated section 11.11 to clarify expected term and

re-enroll scenarios

• Updated section 11.16 for list of QLE Identifiers

• Updated section 12.1 ISA15 to clarify usage

• Updated section 12.2 to use CSR instead of CS for

Cost Sharing Reduction

• Updated section 12.2 to clarify usage of 2300 REF X9

• Updated section 12.3.1 and 12.4.1 to clarify usage of

2000 DTP 357

• Updated section 13.1.1 to clarify timing of

termination process for passive renewed

enrollments

06/07/2021 v21.06.01 Update section 12 for ISA15 behavior GetInsured

© GetInsured 2023 All Rights Reserved.         122

Date 
Document

Version 
Revision Description Author

08/30/2021 v21.09.00

Update section 3, Table 1 for renaming of End of Year

termination, updated comments including footnote

numbering.

Update section 9, Table 3 for GS06 to clarify the requirement

for unique GS06 control numbers on inbound 834

transactions.

Update section 11:

• 11.1 update 2100A LUI02 to reference section 17

• 11.1 indicate “when applicable” for 2750 loops that

are conditionally sent

Update section 13:

• 13.1.1 for updated process for End of Coverage Year

Terms

• 13.1.3 to clarify usage

• 13.1.4 to update title and clarify usage of 024*07

termination transactions

• 13.1.5, table 25, 2000 loop INS04 to clarify usage

Update section 16.1 to add ‘59’ Non-Payment and remove

decommissioned ‘29’ Benefit Selection from Table 28 Term

maintenance reason codes.

Insert new section 17 with Table 31 for spoken and Table 32

for written language codes. Renumbered Appendix to

section 18 and Document Control to section 19.

GetInsured

09/01/2021 v21.09.01 Update Section 3 to reformat Table 1 GetInsured

11/29/2021 v22.01.00 Update Section 3, Table 1 column header content GetInsured

2/28/2022 v22.03.00

Update Section 13.1.6 to clarify add a member system

behavior for passive renewals

Insert Section 18 for Race/Ethnicity codes.

Renumber Section 18 Appendix to Section 19, and Section 19

Document Control to Section 20.

GetInsured

6/06/2022 v22.06.00

---

[Source: direct_files, File: GAMMIS_5010_834_Companion_Guide_v2.30 20231228171319.pdf, Chunk: 194/null]
.

Modifications made for CSR 1019: 
Section 4.2:  Modify ‘There are 4 types of 834 
files for Managed Care section to reflect 2 
types.  Modify File Naming Convention for 
Inbound 834.  Modify File Naming Convention 
for Outbound 834. 
Section 6.1:  Modified ISA06 – Removed 
Inbound PCK/P4HB. 
Section 7.9:  Removed Monthly 834 Roster 
and Monthly Variance. 
Section 8.1:  Removed Quarterly 
Reconciliation. 
Section 8.2:  Removed PCK/P4HB Inbound 
Transactions which caused the remaining 
items in section 8 to be renumbered. 
Renumbered Section 8.2:  Under Enrollment 
Broker and CMO added information. 
Renumbered Section 8.2.:  Under Enrollment 
Broker and CMO removed information. 
Section 11.1:  Removed all references to 
Inbound:  PCK/P4HB and Inbound PCK 
(BGN05, 1000A, 1000B, 2000, 2100A, 2100G, 
2300, 2310. 
Section 11.1:  INS03 – Removed Maintenance 
Type Code 025. 
Section 11.1:  Added – 2100G – N3 segment 
information. 
Section 12.1:  Added 11, Removed 28 and 34, 
Changed 33 to 35. 
Section 12.2:  Added 11. 
Section 12:  Removed 12.4, 12.5, 12.6, 12.8 
and 12.10 which caused 12.7 to now be 12.4 
and 12.9 to be 12.5. 
Section 13.6:  Removed Monthly Variance, 
changed Monthly Roster to Monthly Audit 
Roster.

---

[Source: direct_files, File: CG-834_2025-08.pdf, Chunk: 11/null]
MassHealth Standard Companion Guide 005010  (834)   |   page 9

Maintenance 
Type Code 
(INS03)

---

[Source: direct_files, File: GAMMIS_5010_834_Companion_Guide_v2.30 20231228171319.pdf, Chunk: 260/null]
H

2.27 04/01/2023 Sections 2.1, 4, and 
17.3

---

[Source: direct_files, File: EDI-Test Case-20260428.xls, Chunk: 293/null]
r member details
								41	Click Search	Search window should display
								42	Expand Member and double click on SSN	SSN text box should display
								43	Enter SSN (NM1*IL 09) from 834 file and click on Find	Member details should display
								44	Click Ok	Subscriber ID should get populated in Subscriber ID Open window
								45	Click Ok	Subscriber details should display
								46	Double click Addresses tab under Subscriber/Family	Addresses window should be in focus
								47	Select Type - Subscriber Home and verify address details match to 834 file	Subscriber Home details should match
								48	Select Type - Family Address 1 and verify address details match to 834 file

Note: Verify we have a Mailing address in the list of addresses displayed

Mailing address can be Family Address 1 or Family Address 2	Subscriber Mailing Address 1 details should match
	Validate member gets termed in Facets UI when termed with middle Initial	TC-9249		New	Manual Test case			1	Validate TC-9247 inorder to perform this scenario	TC-9247 should be validated

---

[Source: direct_files, File: EDI-Test Case-20260428.xls, Chunk: 8/null]
 path: \\daycrtappfs01\EdifecsSTRoot\834\Inbound	File should be placed in the path: \\daycrtappfs01\EdifecsSTRoot\834\Inbound
								3	login into edifecs TM to view the status of the transaction. Edifecs TM link: https://edifecstm-crt.caresource.corp:8443/tm/logon/logon.jsp	Login to Edifecs TM should be Successfully.
								4	Verify the 834 File is processed with the following conditions:- Validate the status of file for its transaction [~EDI_PUD]	834 File should process with the following conditions: The PUD tab is accessible and show the details of the transactions [~EDI_PudExpected]   result
								5	Verify the 834 file is present in the path: \\daycrtappfs01\EdifecsSTArchive\834\Inbound\State_of_MI	834 File should be present in the path: \\daycrtappfs01\EdifecsSTArchive\834\Inbound\State_of_MI
								6	Launch Facets interface for the CRT environment.	Facets launches successfully.
								7	Select Open Database and Open Facets Product pop up appears with list of PZB filesSelect a PZB file. Press Open. An example filename: "OH - FACETS - CRT_69.pzb"	Facets loads into the selected environment.
								8	Double click "Subscriber/Member"	New window opens
								9	Double click on "Subscriber/Family"	Subscriber/Family opens with all empty information.
								10	Select Open under the File option. (Click cntrl, O OR Right click on , select 'Open', Select 'Search'. popup appears with a box to enter a Subscriber ID. Click search can see the SSN Number give the SSN Number (Present in 834 file) and click on Search then we get the [~EDI_SubGroupId]  . Enter the SubscriberID that met your criteria and select Ok	Subscriber record is displayed
								11	Verify the subscriber details are updated correctly as in the processed Transaction in 834 File.  If transactions are ignored, then the transaction based details shouldn't be update for the member.	Subscriber details should updated into Facets correctly as in the processed Transaction in 834. If transactions are ignored, then the transaction based details shouldn't be update for the member.
								12	Log on to SQL Server, connect to CRT_72.sql.caresource.corp\CRT_72, and run the following query to select * from CMC_MELC_LSTY_CD(nolock) where MEME_CK=''Validate the above cross walk table.	Cross walk table should be updated as expected.
	11. Given 021/28 and 025/18  Transactions are received in the incoming 834	TC-1914		New	Manual Test case			1	Mockup an 834 MI HAP file with an Existing [~EDI_Member]   with two transactions.001/29, 025/18 and 025/41 [~EDI_TestScenario]   025/18 - Completely Retroactive Re-enrollment Segment021/28 - Prospective New Enrollment Note: file name starts with 5790	File should be mocked up
								2	Verify the 834 MI HAP File is placed in the path: \\daycrtappfs01\EdifecsSTRoot\834\Inbound	File should be placed in the path: \\daycrtappfs01\EdifecsSTRoot\834\Inbound
								3	login into edifecs TM to view the status of the transaction. Edifecs TM link: https://edifecstm-crt.caresource.corp:8443/tm/logon/logon.jsp	Login to Edifecs TM should be Successfully.
								4	Verify the 834 File is processed with the following conditions:- Validate the status of file for its transaction [~EDI_PUD]	834 File should process with the following conditions: The PUD tab is accessible and show the details of the transactions [~EDI_PudExpected]   result
								5	Verify the 834 file is present in the path: \\daycrtappfs01\EdifecsSTArchive\834\Inbound\State_of_MI	834 File should be present in the path: \\daycrtappfs01\EdifecsSTArchive\834\Inbound\State_of_MI
								6	Launch Facets interface for the CRT environment.	Facets launches successfully.
								7	Select Open Database and Open Facets Product pop up appears with list of PZB filesSelect a PZB file. Press Open. An example filename: "OH - FACETS - CRT_69.pzb"	Facets loads into the selected environment.
								8	Double click "Subscriber/Member"	New window opens
								9	Double click on "Subscriber/Family"	Subscriber/Family opens with all empty information.
								10	Select Open under the File option. (Click cntrl, O OR Right click on , select 'Open', Select 'Search'. popup appears with a box to enter a Subscriber ID. Click search can see the SSN Number give the SSN Number (Present in 834 file) and click on Search then we get the [~EDI_SubscriberId]  . Enter the SubscriberID that met your criteria and select Ok	Subscriber record is displayed
								11	Verify the subscriber details are updated correctly as in the processed Transaction in 834 File.  If transactions are ignored, then the transaction based details shouldn't be update for the member.	Subscriber details should updated into Facets correctly as in the processed Transaction in 834. If transactions are ignored, then the transaction based details shouldn't be update for the member.
								12	Log on to SQL Server, connect to CRT_72.sql.caresource.corp\CRT_72, and run the following query to select * from CMC_MELC_LSTY_CD(nolock) where MEME_CK=''Vali

---

[Source: direct_files, File: EDI-Test Case-20260428.xls, Chunk: 5/null]
lect a PZB file. Press Open. An example filename: "OH - FACETS - CRT_69.pzb"	Facets loads into the selected environment.
								8	Double click "Subscriber/Member"	New window opens
								9	Double click on "Subscriber/Family"	Subscriber/Family opens with all empty information.
								10	Select Open under the File option. (Click cntrl, O OR Right click on , select 'Open', Select 'Search'. popup appears with a box to enter a Subscriber ID. Click search can see the SSN Number give the [~EDI_SSN]   Number (Present in 834 file) and click on Search then we get the SubscriberID. Enter the [~EDI_SubscriberId]   that met your criteria and select Ok	Subscriber record is displayed
								11	Verify there is no update for the Subscriber in Facets as the Transaction is ignored because effective date is pre 10/1	Subscriber should not be updated in Facets
								12	Log on to SQL Server, connect to CRT_72.sql.caresource.corp\CRT_72, and run the following query to select * from CMC_MELC_LSTY_CD(nolock) where MEME_CK=''Validate the above cross walk table.	Cross walk table should have no update.'
	8. Validate multiple transactions are received in the same file for an existing Facets member with 001/25(pre 10/1 and other post 10/1)	TC-1892		New	Manual Test case			1	Mockup an 834 MI HAP file with an Existing member with multiple transactions.001/25 001/25 - Demographic Changes (First Name, Last Name, Middle Name, SSN, Gender, DOB, Residential County Change) Note: file name starts with 5790	File should be mocked up
								2	Verify the 834 mockup File is placed in the path: \\daycrtappfs01\EdifecsSTRoot\834\Inbound	File should be placed in the path: \\daycrtappfs01\EdifecsSTRoot\834\Inbound
								3	login into edifecs TM to view the status of the transaction. Edifecs TM link: https://edifecstm-crt.caresource.corp:8443/tm/logon/logon.jsp	Login to Edifecs TM should be Successfully.
								4	Verify If the DTP*348 for one of the transaction is pre 10/1 and other post 10/1 then Ignore pre 10/1 and follow new requirement for post 10/1. Process post 10/01 001/25 Transaction	834 File should process with following conditions.
								5	Verify the 834 file is present in the path: \\daycrtappfs01\EdifecsSTArchive\834\Inbound\State_of_MI	834 File should be present in the path: \\daycrtappfs01\EdifecsSTArchive\834\Inbound\State_of_MI
								6	Launch Facets interface for the CRT environment.	Facets launches successfully.
								7	Select Open Database and Open Facets Product pop up appears with list of PZB filesSelect a PZB file. Press Open. An example filename: "OH - FACETS - CRT_69.pzb"	Facets loads into the selected environment.
								8	Double click "Subscriber/Member"	New window opens
								9	Double click on "Subscriber/Family"	Subscriber/Family opens with all empty information.
								10	Select Open under the File option. (Click cntrl, O OR Right click on , select 'Open', Select 'Search'. popup appears with a box to enter a Subscriber ID. Click search can see the SSN Number give the [~EDI_SSN]   Number (Present in 834 file) and click on Search then we get the SubscriberID. Enter the [~EDI_SubscriberId]   that met your criteria and select Ok	Subscriber record is displayed
								11	Verify the subscriber details are updated correctly as in the processed Transaction in 834 File. If transactions are ignored, then the transaction-based details shouldn't be update for the member.	Subscriber details should updated into Facets correctly as in the processed Transaction in 834. If transactions are ignored, then the transaction based details shouldn't be update for the member.
								12	Log on to SQL Server, connect to CRT_72.sql.caresource.corp\CRT_72, and run the following query to select * from CMC_MELC_LSTY_CD(nolock) where MEME_CK=''Validate the above cross walk table.	Cross walk table should be updated.
	9. Validate multiple transactions are received in the same file for an existing Facets member with 001/25(both post 10/1)	TC-1897		New	Manual Test case			1	Mockup an 834 MI HAP file with an Existing member with multiple transactions.001/25 001/25 - Demographic Changes (First Name, Last Name, Middle Name, SSN, Gender, DOB, Residential County Change) Note: file name starts with 5790	File should be mocked up
								2	Verify the 834 mockup File is placed in the path: \\daycrtappfs01\EdifecsSTRoot\834\Inbound	File should be placed in the path: \\daycrtappfs01\EdifecsSTRoot\834\Inbound
								3	login into edifecs TM to view the status of the transaction. Edifecs TM link: https://edifecstm-crt.caresource.corp:8443/tm/logon/logon.jsp	Login to Edifecs TM should be Successfully.
								4	Verify the 834 file is processed with the following conditions: If the DTP*348 for one of the transaction is pre 10/1 and other post 10/1 then Ignore pre 10/1 and follow new requirement for post 10/1	834 file should processed with following conditions.
								5	Verify the 834 file is present in the path: \\daycrtappfs01\EdifecsSTArchive\834\Inbound\Sta

---

[Source: direct_files, File: EDI-Test Case-20260428.xls, Chunk: 9/null]
date the above cross walk table.	Cross walk table should be updated as expected.
	5. Validate that two transactions are received in the same file for an existing Facets member with 001/25 + 021 / 28	TC-1921		New	Manual Test case			1	Mockup an 834 MI HAP file with an Existing member with two transactions.001/25 and 021/28 001/25 - Demographic Changes (First Name, Last Name, Middle Name, SSN, Gender, DOB, Residential County Change) 021/28 - Prospective New Enrollment Note: file name starts with 5790	File should be mocked up
								2	Verify the 834 mockup File is placed in the path: \\daycrtappfs01\EdifecsSTRoot\834\Inbound	File should be placed in the path: \\daycrtappfs01\EdifecsSTRoot\834\Inbound

---

[Source: direct_files, File: EDI-Test Case-20260428.xls, Chunk: 62/null]
 loop	User should be able to give DOB details
								15	Update the DMG06 with [EDI_Citizenship Status Code]   in DMG segment in 2100A loop	User should be able to give citizenship status code details
								16	Update the DTP03 element with the [EDI_EffectiveDate]   , user can give any random date in DTP*348	User should be able to mockup the DTP segment
								17	Update the EDI_ControlNumber in GE02, IEA02 which was given in ISA and GS segments	User should be able to mockup the control number
								18	Copy the [EDI_FileName_834]   from the prod file and change some numeric value to make file name as unique	File naming convention updated successfully
								19	Place the file in below Inbound location as per [~EDI_Env]
### 🛠️ Tool Initialized  
**Tool:** knowledge_base_answer_retrieval  
**Agent:** EDI 834 Inbound Test Case Generator From JSON Scenarios Embed KB Feedback Updated
**Tool Arguments (JSON):**  
```json
{
  "question": "Generate EDI 834 Inbound AR PASSE test cases for transaction effective date logic using the provided scenarios and rework notes. Retrieve strict guidance from kb_edi_834_testcases_analysis_1_embedded and kb_edi_834_companion_guide_1_embedded on: required test case template/columns, file naming convention for inbound 834, AR PASSE-specific processing steps, server/database details (including DB server name), archive/staging paths, Edifecs TM validation steps, Facets validation expectations, SQL validation guidance including MELC/crosswalk checks, and any sample/manual test case patterns for detailed step formatting."
}
```
### ✅ Agent EDI 834 Inbound Test Case Generator From JSON Scenarios Embed KB Feedback Updated Finished
**Message:**  
[Agent] ✅ 'EDI 834 Inbound Test Case Generator From JSON Scenarios Embed KB Feedback Updated' finished
## Changes Made This Round
- Added explicit traceability fields for each test case: every case includes `ScenarioId` and `AcceptanceCriteriaRef`.
- Applied atomicity by limiting output to 2 focused functional test cases, each validating one primary behavior only.
- Updated preconditions to be scenario-specific with AR PASSE LOB, exact inbound file purpose, exact staging/archive paths, and member state.
- Made expected results measurable with exact segment references, exact TM status checks, exact archive path, and exact SQL validation statements.
- Incorporated missing-scenario coverage partially within the allowed maximum of 2 test cases by prioritizing highest-risk AC1 and AC3 scenarios from the rework notes.
- Used knowledge-base-derived process patterns: MI HAP/834 inbound staging, Edifecs TM validation, archive validation, Facets verification flow, DB server `crt_72.sql.caresource.corp\crt_72`, and MELC/crosswalk checks.
- Aligned steps to detailed manual-test style and included server/database/query references in the step descriptions.

{
  "testcases": "| ScenarioId | AcceptanceCriteriaRef | Name | Id | Attachments | Status | Test Case Type | Description | Precondition | Test Step # | Test Step Description | Test Step Expected Result | Test Step Attachment |\n|---|---|---|---|---|---|---|---|---|---:|---|---|---|\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 1 | Create a copy of a valid MI HAP inbound 834 sample file for AR PASSE and retain the original envelope structure (ISA/GS/ST/SE/GE/IEA) while making the file name unique per companion-guide-based naming convention used in existing inbound files. | A unique AR PASSE-compatible 834 file is prepared and its filename is distinct from prior submissions while preserving valid 834 envelope structure. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 2 | In Loop 2000 of the test file, populate `DTP*356*D8*20250101~`; if implementation also accepts `DTP*348`, populate `DTP*348*D8*20250101~` with the same date to avoid ambiguity for this positive scenario. | The file contains a valid eligibility/effective date segment in Loop 2000 with date value `20250101`. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 3 | In Loop 2300, populate the assessment source field per technical note by setting `HD03` to `ASMT20250115` and ensure the member maintenance detail remains syntactically valid. | The file contains Loop 2300 `HD03=ASMT20250115` and the 2300 loop remains structurally valid. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 4 | Populate maintenance date segment `DTP*303*D8*20241220~` in the applicable maintenance loop for the same member transaction. | The file contains a valid maintenance date segment with value `20241220`. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 5 | Update control numbers consistently in ISA13, GS06, ST02, SE02, GE02, and IEA02 so the file is uniquely processable and internally balanced. | Envelope control numbers are unique and balanced; segment counts and trailer references are internally consistent. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 6 | Save the completed file and place it in the NAS inbound staging folder `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`. | The file is present in `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound` with the expected unique filename. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 7 | Wait for Edifecs pickup and then log in to CRT TM UI at `https://edifecstm-crt.caresource.corp:8443/tm/logon/logon.jsp` using authorized credentials. | CRT TM login succeeds and the user lands on the transmission search page. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 8 | Under Transmissions, select `Last 24 Hours (Batch)` and filter by transaction type `834` or trading partner `MI HAP`, then search for the submitted filename. | The submitted file appears in TM search results under the last 24 hours batch view. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 9 | Open the transmission record and verify the batch processed successfully with no fatal validation errors and that policy unit delivery is completed/successful. | TM shows the file processed successfully; policy unit delivery status is `Completed/Success` or equivalent successful completion state with no blocking error on the transaction. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 10 | Open the transaction attachments/canonical payload in TM and inspect the member transaction to confirm the inbound segments include `DTP*356` or `DTP*348`, `HD03`, and `DTP*303` with the exact values loaded from the file. | Canonical or transaction detail view shows the exact inbound values `20250101`, `ASMT20250115`, and `20241220` for the corresponding source fields. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 11 | Verify the processed physical file is archived to `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`. | The exact submitted filename exists in `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 12 | Connect to SQL Server `crt_72.sql.caresource.corp\\crt_72` using SSMS and open a new query window for validation. | SQL connection to `crt_72.sql.caresource.corp\\crt_72` succeeds and a query window is available. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 13 | Run the crosswalk validation query: `select * from CMC_MELC_LSTY_CD (nolock) where MEME_CK = (select MEME_CK from FACPRDDB.dbo.CMC_MEME_MEMBER where MEME_SSN='{{AR_PASSE_SSN_01}}');` | Query returns 0 rows matching an unexpected crosswalk condition for this scenario, satisfying the requirement that data should not match disallowed crosswalk criteria. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 14 | Run MELC validation query: `select * from FACPRDDB.dbo.CMC_MELC_LSTY_CD (nolock) where MEME_CK = (select MEME_CK from FACPRDDB.dbo.CMC_MEME_MEMBER where MEME_SSN='{{AR_PASSE_SSN_01}}');` and review whether any error/listing row was created due to incorrect data. | No new MELC row attributable to incorrect inbound data is created for `{{AR_PASSE_SSN_01}}`. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 15 | Launch Facets in CRT, open the configured product database, navigate to Subscriber/Family, and search by SSN `{{AR_PASSE_SSN_01}}` or subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`. | The AR PASSE member record opens successfully in Facets for the submitted subscriber. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 16 | Review the processed transaction details available to the member and confirm the transaction completed without member-intake hold or policy-unit error. | No unresolved intake hold or policy unit error is present for the processed transaction. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 17 | Document the exact source-to-value mapping observed during validation: Eligibility Date from `DTP*356/DTP*348=20250101`, Assessment source from `HD03=ASMT20250115`, and Maintenance Date from `DTP*303=20241220`. | Test evidence records the three exact inbound source values and confirms they were identifiable in processing artifacts. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 18 | Capture screenshots or exported evidence from TM search result, TM transaction detail/canonical view, archive folder listing, and SQL result sets. | Evidence set contains timestamped proof of successful processing, archive placement, and SQL validation results. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 19 | Compare all observed results against AC1 and confirm no date-identification gap exists for the three required date sources in this positive scenario. | AC1 passes: all three required date sources are present, identifiable, and processed without error. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 20 | Mark the test case outcome and attach the evidence package for downstream review. | Test case is ready for audit with pass/fail decision, traceability, and evidence attached. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 1 | Copy a valid MI HAP inbound 834 sample for AR PASSE and create a unique filename by changing the numeric uniqueness portion while preserving the established inbound naming pattern. | A uniquely named AR PASSE-compatible inbound 834 file is prepared for submission. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 2 | Populate the future eligibility date in Loop 2000 as `DTP*356*D8*20251201~` and, if required by implementation, also populate `DTP*348*D8*20251201~`. | The file contains future eligibility date `20251201` in the accepted eligibility date source segment(s). | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 3 | Populate a different assessment source value in Loop 2300 by setting `HD03=ASMT20251115` so the assessment-related value is earlier than the future eligibility date. | The file contains `HD03=ASMT20251115`, which differs from the future eligibility date. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 4 | Populate maintenance date `DTP*303*D8*20251120~`, also earlier than the future eligibility date, to prove it is not selected for this scenario. | The file contains maintenance date `20251120`, which differs from and is earlier than `20251201`. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 5 | Update ISA/GS/ST control numbers and corresponding GE/IEA/SE references so the file is unique and balanced for processing. | Envelope control numbers are unique and all header/trailer references reconcile correctly. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 6 | Place the file in `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound` and confirm the file is visible in the folder. | The file is present in the inbound staging folder with the expected unique filename. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 7 | Log in to CRT TM UI at `https://edifecstm-crt.caresource.corp:8443/tm/logon/logon.jsp`. | CRT TM login succeeds. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 8 | Under Transmissions, select `Last 24 Hours (Batch)`, filter by transaction `834` or trading partner `MI HAP`, and locate the submitted file. | The submitted file is returned in TM search results. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 9 | Open the transmission and verify successful processing with no fatal validation errors and successful policy unit delivery. | TM shows successful processing and policy unit delivery completed successfully. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 10 | Open transaction details/canonical payload and confirm the inbound values are present exactly as submitted: eligibility `20251201`, assessment source `ASMT20251115`, maintenance `20251120`. | Canonical or transaction detail view shows the exact submitted values for all three source fields. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 11 | Verify the processed file is archived to `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`. | The exact submitted filename exists in the archive folder. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 12 | Connect to SQL Server `crt_72.sql.caresource.corp\\crt_72` and open a new query window. | SQL connection succeeds. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 13 | Run query to retrieve member key and subscriber key: `select MEME_CK, SBSB_CK, MEME_SSN from FACPRDDB.dbo.CMC_MEME_MEMBER where MEME_SSN='{{AR_PASSE_SSN_02}}';` | Query returns exactly one member row for `{{AR_PASSE_SSN_02}}`. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 14 | Run eligibility query: `SELECT * FROM FACPRDDB.dbo.CMC_SBEL_ELIG_ENT SBEL JOIN FACPRDDB.dbo.CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBEL.SBSB_CK WHERE MEME.MEME_SSN='{{AR_PASSE_SSN_02}}' ORDER BY SBEL_EFF_DT;` | At least one eligibility row exists for the member with effective date `2025-12-01` or `20251201` depending on DB display format. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 15 | Run processed eligibility query: `SELECT * FROM FACPRDDB.dbo.CMC_MEPE_PRCS_ELIG MEPE JOIN FACPRDDB.dbo.CMC_MEME_MEMBER MEME ON MEME.MEME_CK = MEPE.MEME_CK WHERE MEME.MEME_SSN='{{AR_PASSE_SSN_02}}' ORDER BY MEPE_EFF_DT;` | Processed eligibility rows include an effective date row beginning `2025-12-01`/`20251201` for the future enrollment. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 16 | Launch Facets CRT, open Subscriber/Family, and search for subscriber `{{AR_PASSE_SUBSCRIBER_02}}` or SSN `{{AR_PASSE_SSN_02}}`. | The member/subscriber record opens in Facets. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 17 | Review the transaction effective date displayed/derived in Facets transaction context for the processed enrollment and compare it to the three inbound source values. | The transaction effective date equals `2025-12-01`/`20251201` and does not equal assessment-related `20251115` or maintenance `20251120`. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 18 | Run crosswalk validation query `select * from CMC_MELC_LSTY_CD (nolock) where MEME_CK = (select MEME_CK from FACPRDDB.dbo.CMC_MEME_MEMBER where MEME_SSN='{{AR_PASSE_SSN_02}}');` and confirm no disallowed crosswalk row is created. | Query returns no unexpected crosswalk match rows for the member. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 19 | Capture evidence from TM, archive folder, Facets transaction view, and SQL result sets showing the selected effective date equals the eligibility date. | Evidence package clearly shows transaction effective date `20251201` and excludes `20251115` and `20251120` as selected values. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 20 | Record final outcome and pass the completed test case with scenariojson traceability to the next agent. | Test case is audit-ready, mapped to TS_008/AC3, and ready for downstream consumption. | None |",
  "scenariojson": "[{\"scenarioId\":\"TS_001\",\"title\":\"Identify Eligibility, Assessment, and Maintenance Dates from inbound 834\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Positive\",\"description\":\"Validate that inbound EDI 834 processing identifies Eligibility Date from Loop 2000 DTP*356/DTP*348, Assessment Date from Loop 2300 HD03, and Maintenance Date from DTP*303 for transaction effective date evaluation.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_002\",\"title\":\"Identify first occurrence when multiple date values are received\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Edge\",\"description\":\"Validate that when multiple inbound date occurrences are present, the first applicable date is identified and used per technical guidance.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_003\",\"title\":\"Handle missing required date elements during date identification\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Negative\",\"description\":\"Validate that inbound processing flags a date identification gap when one or more of Eligibility Date, Assessment Date, or Maintenance Date required for rule evaluation are missing from the 834.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_004\",\"title\":\"Populate Facets transaction effective date with identified Eligibility Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Eligibility Date can be populated into the Facets transaction effective date field.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_005\",\"title\":\"Populate Facets transaction effective date with identified Assessment Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Assessment Date can be populated into the Facets transaction effective date field.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_006\",\"title\":\"Populate Facets transaction effective date with identified Maintenance Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Maintenance Date can be populated into the Facets transaction effective date field when selected by business rules.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_007\",\"title\":\"Prevent unsupported date population to Facets transaction effective date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Negative\",\"description\":\"Validate that Facets transaction effective date is not populated from any inbound date other than the identified Eligibility Date, Assessment Date, or Maintenance Date.\",\"priority\":\"Medium\"},{\"scenarioId\":\"TS_008\",\"title\":\"Use Eligibility Date for future new enrollment regardless of Assessment Date\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that for an inbound new enrollment where the member eligibility span has not yet begun, the transaction effective date in Facets is populated with the Eligibility Date even when Assessment Date differs.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_009\",\"title\":\"Use Eligibility Date when future eligibility and Assessment Date is earlier\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that for future eligibility spans the Eligibility Date is used as transaction effective date when Assessment Date is earlier than the Eligibility Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_010\",\"title\":\"Do not use Assessment or Maintenance Date for future eligibility enrollment\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that for a member whose eligibility span has not yet begun, Assessment Date and Maintenance Date are not used as the transaction effective date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_011\",\"title\":\"Use Assessment Date when current eligibility exists and Assessment Date changes\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when the member eligibility span has already begun and the inbound Assessment Date changes, the transaction effective date in Facets is populated with the Assessment Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_012\",\"title\":\"Use changed Assessment Date for current eligibility regardless of Eligibility Date value\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that for current eligibility the changed Assessment Date is selected as transaction effective date even when the Eligibility Date remains unchanged or differs.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_013\",\"title\":\"Do not use Maintenance Date when current eligibility Assessment Date changed\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used as the transaction effective date when current eligibility exists and the Assessment Date has changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_014\",\"title\":\"Use Assessment Date when only Assessment Date changes and relevant fields remain unchanged\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Positive\",\"description\":\"Validate that when Assessment Date changes and Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, and Pregnancy remain unchanged, the Assessment Date populates as the transaction effective date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_015\",\"title\":\"Maintain relevant field values when only Assessment Date changes\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Positive\",\"description\":\"Validate that relevant field values are preserved in Facets when Assessment Date changes but no relevant field change is received.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_016\",\"title\":\"Detect relevant field change and avoid AC5 path\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Negative\",\"description\":\"Validate that AC5 logic is not applied when any relevant field among Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy has changed along with Assessment Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_017\",\"title\":\"Use Eligibility Date for future eligibility with relevant field changes and unchanged Assessment Date\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when eligibility has not yet begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with the Eligibility Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_018\",\"title\":\"Apply Eligibility Date for each relevant field change before eligibility start\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that Eligibility Date is used as transaction effective date when any single relevant field change is received before eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_019\",\"title\":\"Do not use Maintenance Date before eligibility start when Assessment Date is unchanged\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used as the transaction effective date when relevant field changes are received before eligibility start and Assessment Date is unchanged.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_020\",\"title\":\"Use Maintenance Date for current eligibility with relevant field changes and unchanged Assessment Date\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when eligibility has already begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with Maintenance Date DTP*303.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_021\",\"title\":\"Apply Maintenance Date for each relevant field change after eligibility start\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that Maintenance Date is used as transaction effective date when any single relevant field change is received after eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_022\",\"title\":\"Do not use Eligibility Date for current eligibility relevant field changes when Assessment Date is unchanged\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Eligibility Date is not used as the transaction effective date when relevant field changes are received after eligibility start and Assessment Date is unchanged.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_023\",\"title\":\"Maintenance Date used only in explicitly allowed scenario\",\"acceptanceCriteriaRef\":\"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.\",\"type\":\"Positive\",\"description\":\"Validate that Maintenance Date is used only for inbound changes to relevant fields when eligibility has already begun and Assessment Date has not changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_024\",\"title\":\"Prevent Maintenance Date usage for new enrollment and Assessment Date change scenarios\",\"acceptanceCriteriaRef\":\"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used for new enrollments, future eligibility updates, or scenarios where Assessment Date has changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_025\",\"title\":\"Regression coverage for mixed inbound combinations of dates and relevant field changes\",\"acceptanceCriteriaRef\":\"QA Regression - Test inbound 834 files with varying combinations of Eligibility Date, Assessment Date changes, and relevant field changes to verify correct transaction effective date population.\",\"type\":\"Edge\",\"description\":\"Validate correct transaction effective date selection across mixed inbound combinations of future eligibility, current eligibility, Assessment Date changes, and relevant field changes in repeated 2000 and 2300 loop occurrences.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_026\",\"title\":\"Verify no finance-impacting regression from effective date logic update\",\"acceptanceCriteriaRef\":\"QA Regression - Verify no change in capitation calculations and accurate reporting for finance team.\",\"type\":\"Positive\",\"description\":\"Validate that the updated inbound transaction effective date logic does not introduce capitation calculation mismatches or finance reporting inaccuracies downstream.\",\"priority\":\"Medium\"},{\"scenarioId\":\"TS_027\",\"title\":\"Flag knowledge gap when Assessment Date source conflicts with acceptance criteria wording\",\"acceptanceCriteriaRef\":\"AC1-AC7 - Technical Notes and Acceptance Criteria alignment\",\"type\":\"Edge\",\"description\":\"Validate rule execution while flagging that technical notes identify Assessment Date at Loop 2300 HD03 and acceptance criteria reference date-based logic, so any source-field ambiguity must be recorded without blocking remaining scenario coverage.\",\"priority\":\"Low\"}]"
}
### 🎯 Task Finished
**Message:**  
[Task] ✅ Task finished
## Changes Made This Round
- Added explicit traceability fields for each test case: every case includes `ScenarioId` and `AcceptanceCriteriaRef`.
- Applied atomicity by limiting output to 2 focused functional test cases, each validating one primary behavior only.
- Updated preconditions to be scenario-specific with AR PASSE LOB, exact inbound file purpose, exact staging/archive paths, and member state.
- Made expected results measurable with exact segment references, exact TM status checks, exact archive path, and exact SQL validation statements.
- Incorporated missing-scenario coverage partially within the allowed maximum of 2 test cases by prioritizing highest-risk AC1 and AC3 scenarios from the rework notes.
- Used knowledge-base-derived process patterns: MI HAP/834 inbound staging, Edifecs TM validation, archive validation, Facets verification flow, DB server `crt_72.sql.caresource.corp\crt_72`, and MELC/crosswalk checks.
- Aligned steps to detailed manual-test style and included server/database/query references in the step descriptions.

{
  "testcases": "| ScenarioId | AcceptanceCriteriaRef | Name | Id | Attachments | Status | Test Case Type | Description | Precondition | Test Step # | Test Step Description | Test Step Expected Result | Test Step Attachment |\n|---|---|---|---|---|---|---|---|---|---:|---|---|---|\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 1 | Create a copy of a valid MI HAP inbound 834 sample file for AR PASSE and retain the original envelope structure (ISA/GS/ST/SE/GE/IEA) while making the file name unique per companion-guide-based naming convention used in existing inbound files. | A unique AR PASSE-compatible 834 file is prepared and its filename is distinct from prior submissions while preserving valid 834 envelope structure. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 2 | In Loop 2000 of the test file, populate `DTP*356*D8*20250101~`; if implementation also accepts `DTP*348`, populate `DTP*348*D8*20250101~` with the same date to avoid ambiguity for this positive scenario. | The file contains a valid eligibility/effective date segment in Loop 2000 with date value `20250101`. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 3 | In Loop 2300, populate the assessment source field per technical note by setting `HD03` to `ASMT20250115` and ensure the member maintenance detail remains syntactically valid. | The file contains Loop 2300 `HD03=ASMT20250115` and the 2300 loop remains structurally valid. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 4 | Populate maintenance date segment `DTP*303*D8*20241220~` in the applicable maintenance loop for the same member transaction. | The file contains a valid maintenance date segment with value `20241220`. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 5 | Update control numbers consistently in ISA13, GS06, ST02, SE02, GE02, and IEA02 so the file is uniquely processable and internally balanced. | Envelope control numbers are unique and balanced; segment counts and trailer references are internally consistent. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 6 | Save the completed file and place it in the NAS inbound staging folder `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`. | The file is present in `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound` with the expected unique filename. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 7 | Wait for Edifecs pickup and then log in to CRT TM UI at `https://edifecstm-crt.caresource.corp:8443/tm/logon/logon.jsp` using authorized credentials. | CRT TM login succeeds and the user lands on the transmission search page. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 8 | Under Transmissions, select `Last 24 Hours (Batch)` and filter by transaction type `834` or trading partner `MI HAP`, then search for the submitted filename. | The submitted file appears in TM search results under the last 24 hours batch view. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 9 | Open the transmission record and verify the batch processed successfully with no fatal validation errors and that policy unit delivery is completed/successful. | TM shows the file processed successfully; policy unit delivery status is `Completed/Success` or equivalent successful completion state with no blocking error on the transaction. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 10 | Open the transaction attachments/canonical payload in TM and inspect the member transaction to confirm the inbound segments include `DTP*356` or `DTP*348`, `HD03`, and `DTP*303` with the exact values loaded from the file. | Canonical or transaction detail view shows the exact inbound values `20250101`, `ASMT20250115`, and `20241220` for the corresponding source fields. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 11 | Verify the processed physical file is archived to `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`. | The exact submitted filename exists in `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 12 | Connect to SQL Server `crt_72.sql.caresource.corp\\crt_72` using SSMS and open a new query window for validation. | SQL connection to `crt_72.sql.caresource.corp\\crt_72` succeeds and a query window is available. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 13 | Run the crosswalk validation query: `select * from CMC_MELC_LSTY_CD (nolock) where MEME_CK = (select MEME_CK from FACPRDDB.dbo.CMC_MEME_MEMBER where MEME_SSN='{{AR_PASSE_SSN_01}}');` | Query returns 0 rows matching an unexpected crosswalk condition for this scenario, satisfying the requirement that data should not match disallowed crosswalk criteria. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 14 | Run MELC validation query: `select * from FACPRDDB.dbo.CMC_MELC_LSTY_CD (nolock) where MEME_CK = (select MEME_CK from FACPRDDB.dbo.CMC_MEME_MEMBER where MEME_SSN='{{AR_PASSE_SSN_01}}');` and review whether any error/listing row was created due to incorrect data. | No new MELC row attributable to incorrect inbound data is created for `{{AR_PASSE_SSN_01}}`. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 15 | Launch Facets in CRT, open the configured product database, navigate to Subscriber/Family, and search by SSN `{{AR_PASSE_SSN_01}}` or subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`. | The AR PASSE member record opens successfully in Facets for the submitted subscriber. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 16 | Review the processed transaction details available to the member and confirm the transaction completed without member-intake hold or policy-unit error. | No unresolved intake hold or policy unit error is present for the processed transaction. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 17 | Document the exact source-to-value mapping observed during validation: Eligibility Date from `DTP*356/DTP*348=20250101`, Assessment source from `HD03=ASMT20250115`, and Maintenance Date from `DTP*303=20241220`. | Test evidence records the three exact inbound source values and confirms they were identifiable in processing artifacts. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 18 | Capture screenshots or exported evidence from TM search result, TM transaction detail/canonical view, archive folder listing, and SQL result sets. | Evidence set contains timestamped proof of successful processing, archive placement, and SQL validation results. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 19 | Compare all observed results against AC1 and confirm no date-identification gap exists for the three required date sources in this positive scenario. | AC1 passes: all three required date sources are present, identifiable, and processed without error. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 20 | Mark the test case outcome and attach the evidence package for downstream review. | Test case is ready for audit with pass/fail decision, traceability, and evidence attached. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 1 | Copy a valid MI HAP inbound 834 sample for AR PASSE and create a unique filename by changing the numeric uniqueness portion while preserving the established inbound naming pattern. | A uniquely named AR PASSE-compatible inbound 834 file is prepared for submission. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 2 | Populate the future eligibility date in Loop 2000 as `DTP*356*D8*20251201~` and, if required by implementation, also populate `DTP*348*D8*20251201~`. | The file contains future eligibility date `20251201` in the accepted eligibility date source segment(s). | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 3 | Populate a different assessment source value in Loop 2300 by setting `HD03=ASMT20251115` so the assessment-related value is earlier than the future eligibility date. | The file contains `HD03=ASMT20251115`, which differs from the future eligibility date. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 4 | Populate maintenance date `DTP*303*D8*20251120~`, also earlier than the future eligibility date, to prove it is not selected for this scenario. | The file contains maintenance date `20251120`, which differs from and is earlier than `20251201`. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 5 | Update ISA/GS/ST control numbers and corresponding GE/IEA/SE references so the file is unique and balanced for processing. | Envelope control numbers are unique and all header/trailer references reconcile correctly. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 6 | Place the file in `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound` and confirm the file is visible in the folder. | The file is present in the inbound staging folder with the expected unique filename. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 7 | Log in to CRT TM UI at `https://edifecstm-crt.caresource.corp:8443/tm/logon/logon.jsp`. | CRT TM login succeeds. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 8 | Under Transmissions, select `Last 24 Hours (Batch)`, filter by transaction `834` or trading partner `MI HAP`, and locate the submitted file. | The submitted file is returned in TM search results. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 9 | Open the transmission and verify successful processing with no fatal validation errors and successful policy unit delivery. | TM shows successful processing and policy unit delivery completed successfully. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 10 | Open transaction details/canonical payload and confirm the inbound values are present exactly as submitted: eligibility `20251201`, assessment source `ASMT20251115`, maintenance `20251120`. | Canonical or transaction detail view shows the exact submitted values for all three source fields. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 11 | Verify the processed file is archived to `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`. | The exact submitted filename exists in the archive folder. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 12 | Connect to SQL Server `crt_72.sql.caresource.corp\\crt_72` and open a new query window. | SQL connection succeeds. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 13 | Run query to retrieve member key and subscriber key: `select MEME_CK, SBSB_CK, MEME_SSN from FACPRDDB.dbo.CMC_MEME_MEMBER where MEME_SSN='{{AR_PASSE_SSN_02}}';` | Query returns exactly one member row for `{{AR_PASSE_SSN_02}}`. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 14 | Run eligibility query: `SELECT * FROM FACPRDDB.dbo.CMC_SBEL_ELIG_ENT SBEL JOIN FACPRDDB.dbo.CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBEL.SBSB_CK WHERE MEME.MEME_SSN='{{AR_PASSE_SSN_02}}' ORDER BY SBEL_EFF_DT;` | At least one eligibility row exists for the member with effective date `2025-12-01` or `20251201` depending on DB display format. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 15 | Run processed eligibility query: `SELECT * FROM FACPRDDB.dbo.CMC_MEPE_PRCS_ELIG MEPE JOIN FACPRDDB.dbo.CMC_MEME_MEMBER MEME ON MEME.MEME_CK = MEPE.MEME_CK WHERE MEME.MEME_SSN='{{AR_PASSE_SSN_02}}' ORDER BY MEPE_EFF_DT;` | Processed eligibility rows include an effective date row beginning `2025-12-01`/`20251201` for the future enrollment. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 16 | Launch Facets CRT, open Subscriber/Family, and search for subscriber `{{AR_PASSE_SUBSCRIBER_02}}` or SSN `{{AR_PASSE_SSN_02}}`. | The member/subscriber record opens in Facets. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 17 | Review the transaction effective date displayed/derived in Facets transaction context for the processed enrollment and compare it to the three inbound source values. | The transaction effective date equals `2025-12-01`/`20251201` and does not equal assessment-related `20251115` or maintenance `20251120`. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 18 | Run crosswalk validation query `select * from CMC_MELC_LSTY_CD (nolock) where MEME_CK = (select MEME_CK from FACPRDDB.dbo.CMC_MEME_MEMBER where MEME_SSN='{{AR_PASSE_SSN_02}}');` and confirm no disallowed crosswalk row is created. | Query returns no unexpected crosswalk match rows for the member. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 19 | Capture evidence from TM, archive folder, Facets transaction view, and SQL result sets showing the selected effective date equals the eligibility date. | Evidence package clearly shows transaction effective date `20251201` and excludes `20251115` and `20251120` as selected values. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 20 | Record final outcome and pass the completed test case with scenariojson traceability to the next agent. | Test case is audit-ready, mapped to TS_008/AC3, and ready for downstream consumption. | None |",
  "scenariojson": "[{\"scenarioId\":\"TS_001\",\"title\":\"Identify Eligibility, Assessment, and Maintenance Dates from inbound 834\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Positive\",\"description\":\"Validate that inbound EDI 834 processing identifies Eligibility Date from Loop 2000 DTP*356/DTP*348, Assessment Date from Loop 2300 HD03, and Maintenance Date from DTP*303 for transaction effective date evaluation.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_002\",\"title\":\"Identify first occurrence when multiple date values are received\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Edge\",\"description\":\"Validate that when multiple inbound date occurrences are present, the first applicable date is identified and used per technical guidance.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_003\",\"title\":\"Handle missing required date elements during date identification\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Negative\",\"description\":\"Validate that inbound processing flags a date identification gap when one or more of Eligibility Date, Assessment Date, or Maintenance Date required for rule evaluation are missing from the 834.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_004\",\"title\":\"Populate Facets transaction effective date with identified Eligibility Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Eligibility Date can be populated into the Facets transaction effective date field.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_005\",\"title\":\"Populate Facets transaction effective date with identified Assessment Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Assessment Date can be populated into the Facets transaction effective date field.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_006\",\"title\":\"Populate Facets transaction effective date with identified Maintenance Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Maintenance Date can be populated into the Facets transaction effective date field when selected by business rules.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_007\",\"title\":\"Prevent unsupported date population to Facets transaction effective date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Negative\",\"description\":\"Validate that Facets transaction effective date is not populated from any inbound date other than the identified Eligibility Date, Assessment Date, or Maintenance Date.\",\"priority\":\"Medium\"},{\"scenarioId\":\"TS_008\",\"title\":\"Use Eligibility Date for future new enrollment regardless of Assessment Date\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that for an inbound new enrollment where the member eligibility span has not yet begun, the transaction effective date in Facets is populated with the Eligibility Date even when Assessment Date differs.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_009\",\"title\":\"Use Eligibility Date when future eligibility and Assessment Date is earlier\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that for future eligibility spans the Eligibility Date is used as transaction effective date when Assessment Date is earlier than the Eligibility Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_010\",\"title\":\"Do not use Assessment or Maintenance Date for future eligibility enrollment\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that for a member whose eligibility span has not yet begun, Assessment Date and Maintenance Date are not used as the transaction effective date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_011\",\"title\":\"Use Assessment Date when current eligibility exists and Assessment Date changes\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when the member eligibility span has already begun and the inbound Assessment Date changes, the transaction effective date in Facets is populated with the Assessment Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_012\",\"title\":\"Use changed Assessment Date for current eligibility regardless of Eligibility Date value\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that for current eligibility the changed Assessment Date is selected as transaction effective date even when the Eligibility Date remains unchanged or differs.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_013\",\"title\":\"Do not use Maintenance Date when current eligibility Assessment Date changed\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used as the transaction effective date when current eligibility exists and the Assessment Date has changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_014\",\"title\":\"Use Assessment Date when only Assessment Date changes and relevant fields remain unchanged\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Positive\",\"description\":\"Validate that when Assessment Date changes and Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, and Pregnancy remain unchanged, the Assessment Date populates as the transaction effective date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_015\",\"title\":\"Maintain relevant field values when only Assessment Date changes\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Positive\",\"description\":\"Validate that relevant field values are preserved in Facets when Assessment Date changes but no relevant field change is received.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_016\",\"title\":\"Detect relevant field change and avoid AC5 path\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Negative\",\"description\":\"Validate that AC5 logic is not applied when any relevant field among Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy has changed along with Assessment Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_017\",\"title\":\"Use Eligibility Date for future eligibility with relevant field changes and unchanged Assessment Date\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when eligibility has not yet begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with the Eligibility Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_018\",\"title\":\"Apply Eligibility Date for each relevant field change before eligibility start\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that Eligibility Date is used as transaction effective date when any single relevant field change is received before eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_019\",\"title\":\"Do not use Maintenance Date before eligibility start when Assessment Date is unchanged\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used as the transaction effective date when relevant field changes are received before eligibility start and Assessment Date is unchanged.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_020\",\"title\":\"Use Maintenance Date for current eligibility with relevant field changes and unchanged Assessment Date\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when eligibility has already begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with Maintenance Date DTP*303.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_021\",\"title\":\"Apply Maintenance Date for each relevant field change after eligibility start\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that Maintenance Date is used as transaction effective date when any single relevant field change is received after eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_022\",\"title\":\"Do not use Eligibility Date for current eligibility relevant field changes when Assessment Date is unchanged\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Eligibility Date is not used as the transaction effective date when relevant field changes are received after eligibility start and Assessment Date is unchanged.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_023\",\"title\":\"Maintenance Date used only in explicitly allowed scenario\",\"acceptanceCriteriaRef\":\"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.\",\"type\":\"Positive\",\"description\":\"Validate that Maintenance Date is used only for inbound changes to relevant fields when eligibility has already begun and Assessment Date has not changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_024\",\"title\":\"Prevent Maintenance Date usage for new enrollment and Assessment Date change scenarios\",\"acceptanceCriteriaRef\":\"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used for new enrollments, future eligibility updates, or scenarios where Assessment Date has changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_025\",\"title\":\"Regression coverage for mixed inbound combinations of dates and relevant field changes\",\"acceptanceCriteriaRef\":\"QA Regression - Test inbound 834 files with varying combinations of Eligibility Date, Assessment Date changes, and relevant field changes to verify correct transaction effective date population.\",\"type\":\"Edge\",\"description\":\"Validate correct transaction effective date selection across mixed inbound combinations of future eligibility, current eligibility, Assessment Date changes, and relevant field changes in repeated 2000 and 2300 loop occurrences.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_026\",\"title\":\"Verify no finance-impacting regression from effective date logic update\",\"acceptanceCriteriaRef\":\"QA Regression - Verify no change in capitation calculations and accurate reporting for finance team.\",\"type\":\"Positive\",\"description\":\"Validate that the updated inbound transaction effective date logic does not introduce capitation calculation mismatches or finance reporting inaccuracies downstream.\",\"priority\":\"Medium\"},{\"scenarioId\":\"TS_027\",\"title\":\"Flag knowledge gap when Assessment Date source conflicts with acceptance criteria wording\",\"acceptanceCriteriaRef\":\"AC1-AC7 - Technical Notes and Acceptance Criteria alignment\",\"type\":\"Edge\",\"description\":\"Validate rule execution while flagging that technical notes identify Assessment Date at Loop 2300 HD03 and acceptance criteria reference date-based logic, so any source-field ambiguity must be recorded without blocking remaining scenario coverage.\",\"priority\":\"Low\"}]"
}
**Message:** [Agent] 🤖 'Test Case Reviewer LLM as a Judge Test4 wf2' started
**Agent Name:** Test Case Reviewer LLM as a Judge Test4 wf2
**Agent Role:** Independent test case quality reviewer
**Agent Goal:** Review the generated test cases against the scenario list, the original Jira story, and the extracted preconditions. Give an honest, critical assessment. Output a structured JSON verdict. this IS the confidence score the self-healing loop gates on.
State the primary outcome this agent should achieve (e.g., automate weekly status report).

**Agent Backstory:**  
You are a senior QA lead with no knowledge of what the generator intended. You read the story, the scenarios, the preconditions, and the proposed test cases, and give an independent opinion.
You are not trying to be nice - you are trying to catch gaps and precondition mismatches before a human reviewer (or a tester) wastes time on an incomplete or wrongly-grounded set.
Explain the context or scenario that led to creating this agent (e.g., built to reduce manual QA effort).

**Task Prompt:**  
# Role




You are an independent QA reviewer. You did NOT write these test cases. Judge them critically and honestly. Output ONLY a JSON verdict — no prose, no markdown, no code fences.




# Input




Input will be coming from the previous agent, which is a JSON object having test cases. Parse it first. It has exactly two fields:




- **testcases** — the generated test cases as a MARKDOWN TABLE. Columns are:




  Name | Id | Attachments | Status | Test Case Type | Description | Precondition | Test Step # | Test Step Description | Test Step Expected Result | Test Step Attachment




  Each test case has an Id like `TC_MIHAP_001` (starts with "TC", ends in a number). A single test case spans multiple rows — one row per test step (the Id/Name repeat or are blank on continuation rows). "Test Case Type" is one of Positive, Negative, Edge.




- **scenariojson** — the scenario list each test case should map to (the previous agent emits this field as `scenariojson`, NOT `scenarios`). Each scenario object has: `scenarioId` (e.g. `TS_001`), `title`, `acceptanceCriteriaRef`, `type`, `description`, `priority`. There is NO separate story, epic, or preconditions input. Trace test cases using the `scenariojson` list only (specifically each scenario's `scenarioId` and `acceptanceCriteriaRef`).




**IMPORTANT — retain scenarios verbatim (CRITICAL):**




 




Immediately after parsing the input JSON, treat the value of the `scenariojson` field as an IMMUTABLE object.




 




The `scenariojson` array is the single source of truth and MUST NEVER be reconstructed, regenerated, reformatted, summarized, inferred, or recreated from memory.




 




For both:




- the JSON output payload, and




- the REST API Form Data Caller tool invocation,




 




copy the EXACT parsed `scenariojson` value from the input without making ANY modification.




 




The copied value MUST preserve:




- every scenario object,




- every field,




- field order,




- array order,




- values,




- whitespace inside string values,




- escaping,




- and all JSON content exactly as received.




 




NEVER:




- replace it with a placeholder,




- replace it with the name of another agent,




- replace it with "...",




- replace it with an empty array,




- regenerate it from your reasoning,




- omit it because it was already reviewed.




 




If you cannot reproduce the exact parsed value, STOP and treat it as an error instead of inventing or reconstructing a replacement.




# Review Checklist (work through each point)




1. **SCENARIO COVERAGE** — Does every scenario in `scenariojson` have at least one corresponding test case in the table? Flag any scenario (by `scenarioId`) with zero test cases. More than one test case per scenario is fine ONLY if the scenario genuinely bundles independent mechanisms and each test case covers a distinct one — flag it as a gap if the split looks arbitrary.




2. **ATOMICITY** — This is a primary check. Does any test case bundle several DIFFERENT independent mechanisms/rules into one test case via "repeat steps N-M with X, then with Y, then with Z" prose? That is not proper parameterization — if one sub-part fails, the tester cannot tell which mechanism broke. Flag it explicitly, naming the Id (e.g. `TC_MIHAP_001`) and which distinct mechanisms it improperly bundled; it should have been split into separate test cases. This is DIFFERENT from a legitimate data-driven test case (the SAME single mechanism across several input values) — that is fine and must NOT be flagged.




3. **TRACEABILITY** — Does each test case clearly map to a real scenario in `scenariojson` (by `scenarioId` and/or the scenario's `acceptanceCriteriaRef`)? Flag any test case that maps to no scenario, or cites an acceptance criterion that does not appear in any scenario.




4. **PRECONDITION RELEVANCE** — For each test case's "Precondition" column, does the text actually relate to what that test case is testing? Flag any precondition that looks generic/copied and ignores what the scenario clearly needs, or is empty when the scenario plainly requires one.




5. **NEGATIVE / EDGE COVERAGE** — Given the scenario types (Positive/Negative/Edge), are the corresponding negative-path and edge/boundary test cases actually present, not just the happy path? Flag Negative/Edge scenarios that only got Positive coverage.




6. **CLARITY** — Are the Test Step Description and Test Step Expected Result cells concrete and executable, or vague ("verify it works")? Flag steps with an empty description or empty expected result.




# Scoring




After reviewing all 6 points, assign:




- **confidence**: 0-100 (how confident you are this set is complete, correctly grounded, and correct)




  - **90-100**: excellent coverage, relevant preconditions, well-traced to scenarios, clear steps, no gaps, every test case atomic (no bundled-mechanism "repeat steps" cases)




  - **70-89**: solid coverage, minor gaps or a little vague, but traceability, precondition relevance, and atomicity are all correct




  - **50-69**: real gaps — missing negative/edge cases, weak traceability, any precondition mismatch, OR any test case improperly bundling independent mechanisms via "repeat steps" prose (any one of these alone keeps this below 70)




  - **0-49**: poor coverage, ungrounded, or barely related to the scenarios




- **approved**: true if confidence >= 80, false otherwise




# Condition for Output




If approved is true, pass the input you received as it is as your output. If the confidence score is equal to or above the threshold, add the testcases along with the original output; otherwise, give the original output alone.




[MUST] - Always preserve the test scenarios verbatim in the JSON output payload — copy the exact `scenariojson` array you parsed from your input.




## Output Format (approved = true)




confidence score:<number 1-100>




| ScenarioId | AcceptanceCriteriaRef | Name | Id | Attachments | Status | Test Case Type | Description | Precondition | Test Step # | Test Step Description | Test Step Expected Result | Test Step Attachment |




If approved is false, pass the scenarios from the previous agent as your output with the format below.




## Output Format (approved = false)




```json




{




  "confidence": <number 0-100>,




  "approved": true | false,




  "feedback": "<one concise line a generator could act on: exactly what to fix or add>",




  "strengths": ["<what's good about this set, 0-3 items>"],




  "gaps": ["<specific missing case, precondition mismatch, or clarity issue, 0-5 items — be concrete: 'tc_mihap_003 states db access but tests file naming only' not 'precondition could be better'>"],




  "scenariojson": <the EXACT `scenariojson` array you parsed from your input — the full JSON array of scenario objects, copied verbatim; NOT a placeholder, name, or summary>




}




```




 




Before producing ANY output, perform this mandatory validation:




 




1. Confirm that the `scenariojson` value you are about to output is identical to the `scenariojson` value from the parsed input.




2. Confirm that the `scenariojson` value used in the REST API tool call is identical to the parsed input.




3. Never derive, regenerate, or summarize the scenarios from your reasoning. Always copy the original parsed JSON value.




# Tool Call




Call Tool "REST API Form Data Caller test" with EXACTLY TWO top-level arguments: `form_data` and `confidence_score`. These are SIBLINGS at the same level. `confidence_score` is its OWN separate argument — do NOT put it inside `form_data`, and do NOT put it inside `userInputs`.




The full arguments object MUST have this exact top-level shape:




```json




{




  "form_data": {




    "pipelineId": 169,




    "userInputs": {




      "[{"scenarioId":"TS_001","title":"Identify Eligibility, Assessment, and Maintenance Dates from inbound 834","acceptanceCriteriaRef":"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.","type":"Positive","description":"Validate that inbound EDI 834 processing identifies Eligibility Date from Loop 2000 DTP*356/DTP*348, Assessment Date from Loop 2300 HD03, and Maintenance Date from DTP*303 for transaction effective date evaluation.","priority":"High"},{"scenarioId":"TS_002","title":"Identify first occurrence when multiple date values are received","acceptanceCriteriaRef":"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.","type":"Edge","description":"Validate that when multiple inbound date occurrences are present, the first applicable date is identified and used per technical guidance.","priority":"High"},{"scenarioId":"TS_003","title":"Handle missing required date elements during date identification","acceptanceCriteriaRef":"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.","type":"Negative","description":"Validate that inbound processing flags a date identification gap when one or more of Eligibility Date, Assessment Date, or Maintenance Date required for rule evaluation are missing from the 834.","priority":"High"},{"scenarioId":"TS_004","title":"Populate Facets transaction effective date with identified Eligibility Date","acceptanceCriteriaRef":"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).","type":"Positive","description":"Validate that the identified Eligibility Date can be populated into the Facets transaction effective date field.","priority":"High"},{"scenarioId":"TS_005","title":"Populate Facets transaction effective date with identified Assessment Date","acceptanceCriteriaRef":"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).","type":"Positive","description":"Validate that the identified Assessment Date can be populated into the Facets transaction effective date field.","priority":"High"},{"scenarioId":"TS_006","title":"Populate Facets transaction effective date with identified Maintenance Date","acceptanceCriteriaRef":"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).","type":"Positive","description":"Validate that the identified Maintenance Date can be populated into the Facets transaction effective date field when selected by business rules.","priority":"High"},{"scenarioId":"TS_007","title":"Prevent unsupported date population to Facets transaction effective date","acceptanceCriteriaRef":"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).","type":"Negative","description":"Validate that Facets transaction effective date is not populated from any inbound date other than the identified Eligibility Date, Assessment Date, or Maintenance Date.","priority":"Medium"},{"scenarioId":"TS_008","title":"Use Eligibility Date for future new enrollment regardless of Assessment Date","acceptanceCriteriaRef":"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.","type":"Positive","description":"Validate that for an inbound new enrollment where the member eligibility span has not yet begun, the transaction effective date in Facets is populated with the Eligibility Date even when Assessment Date differs.","priority":"High"},{"scenarioId":"TS_009","title":"Use Eligibility Date when future eligibility and Assessment Date is earlier","acceptanceCriteriaRef":"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.","type":"Edge","description":"Validate that for future eligibility spans the Eligibility Date is used as transaction effective date when Assessment Date is earlier than the Eligibility Date.","priority":"High"},{"scenarioId":"TS_010","title":"Do not use Assessment or Maintenance Date for future eligibility enrollment","acceptanceCriteriaRef":"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.","type":"Negative","description":"Validate that for a member whose eligibility span has not yet begun, Assessment Date and Maintenance Date are not used as the transaction effective date.","priority":"High"},{"scenarioId":"TS_011","title":"Use Assessment Date when current eligibility exists and Assessment Date changes","acceptanceCriteriaRef":"AC4 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.","type":"Positive","description":"Validate that when the member eligibility span has already begun and the inbound Assessment Date changes, the transaction effective date in Facets is populated with the Assessment Date.","priority":"High"},{"scenarioId":"TS_012","title":"Use changed Assessment Date for current eligibility regardless of Eligibility Date value","acceptanceCriteriaRef":"AC4 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.","type":"Edge","description":"Validate that for current eligibility the changed Assessment Date is selected as transaction effective date even when the Eligibility Date remains unchanged or differs.","priority":"High"},{"scenarioId":"TS_013","title":"Do not use Maintenance Date when current eligibility Assessment Date changed","acceptanceCriteriaRef":"AC4 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.","type":"Negative","description":"Validate that Maintenance Date is not used as the transaction effective date when current eligibility exists and the Assessment Date has changed.","priority":"High"},{"scenarioId":"TS_014","title":"Use Assessment Date when only Assessment Date changes and relevant fields remain unchanged","acceptanceCriteriaRef":"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.","type":"Positive","description":"Validate that when Assessment Date changes and Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, and Pregnancy remain unchanged, the Assessment Date populates as the transaction effective date.","priority":"High"},{"scenarioId":"TS_015","title":"Maintain relevant field values when only Assessment Date changes","acceptanceCriteriaRef":"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.","type":"Positive","description":"Validate that relevant field values are preserved in Facets when Assessment Date changes but no relevant field change is received.","priority":"High"},{"scenarioId":"TS_016","title":"Detect relevant field change and avoid AC5 path","acceptanceCriteriaRef":"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.","type":"Negative","description":"Validate that AC5 logic is not applied when any relevant field among Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy has changed along with Assessment Date.","priority":"High"},{"scenarioId":"TS_017","title":"Use Eligibility Date for future eligibility with relevant field changes and unchanged Assessment Date","acceptanceCriteriaRef":"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.","type":"Positive","description":"Validate that when eligibility has not yet begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with the Eligibility Date.","priority":"High"},{"scenarioId":"TS_018","title":"Apply Eligibility Date for each relevant field change before eligibility start","acceptanceCriteriaRef":"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.","type":"Edge","description":"Validate that Eligibility Date is used as transaction effective date when any single relevant field change is received before eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.","priority":"High"},{"scenarioId":"TS_019","title":"Do not use Maintenance Date before eligibility start when Assessment Date is unchanged","acceptanceCriteriaRef":"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.","type":"Negative","description":"Validate that Maintenance Date is not used as the transaction effective date when relevant field changes are received before eligibility start and Assessment Date is unchanged.","priority":"High"},{"scenarioId":"TS_020","title":"Use Maintenance Date for current eligibility with relevant field changes and unchanged Assessment Date","acceptanceCriteriaRef":"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.","type":"Positive","description":"Validate that when eligibility has already begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with Maintenance Date DTP*303.","priority":"High"},{"scenarioId":"TS_021","title":"Apply Maintenance Date for each relevant field change after eligibility start","acceptanceCriteriaRef":"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.","type":"Edge","description":"Validate that Maintenance Date is used as transaction effective date when any single relevant field change is received after eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.","priority":"High"},{"scenarioId":"TS_022","title":"Do not use Eligibility Date for current eligibility relevant field changes when Assessment Date is unchanged","acceptanceCriteriaRef":"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.","type":"Negative","description":"Validate that Eligibility Date is not used as the transaction effective date when relevant field changes are received after eligibility start and Assessment Date is unchanged.","priority":"High"},{"scenarioId":"TS_023","title":"Maintenance Date used only in explicitly allowed scenario","acceptanceCriteriaRef":"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.","type":"Positive","description":"Validate that Maintenance Date is used only for inbound changes to relevant fields when eligibility has already begun and Assessment Date has not changed.","priority":"High"},{"scenarioId":"TS_024","title":"Prevent Maintenance Date usage for new enrollment and Assessment Date change scenarios","acceptanceCriteriaRef":"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.","type":"Negative","description":"Validate that Maintenance Date is not used for new enrollments, future eligibility updates, or scenarios where Assessment Date has changed.","priority":"High"},{"scenarioId":"TS_025","title":"Regression coverage for mixed inbound combinations of dates and relevant field changes","acceptanceCriteriaRef":"QA Regression - Test inbound 834 files with varying combinations of Eligibility Date, Assessment Date changes, and relevant field changes to verify correct transaction effective date population.","type":"Edge","description":"Validate correct transaction effective date selection across mixed inbound combinations of future eligibility, current eligibility, Assessment Date changes, and relevant field changes in repeated 2000 and 2300 loop occurrences.","priority":"High"},{"scenarioId":"TS_026","title":"Verify no finance-impacting regression from effective date logic update","acceptanceCriteriaRef":"QA Regression - Verify no change in capitation calculations and accurate reporting for finance team.","type":"Positive","description":"Validate that the updated inbound transaction effective date logic does not introduce capitation calculation mismatches or finance reporting inaccuracies downstream.","priority":"Medium"},{"scenarioId":"TS_027","title":"Flag knowledge gap when Assessment Date source conflicts with acceptance criteria wording","acceptanceCriteriaRef":"AC1-AC7 - Technical Notes and Acceptance Criteria alignment","type":"Edge","description":"Validate rule execution while flagging that technical notes identify Assessment Date at Loop 2300 HD03 and acceptance criteria reference date-based logic, so any source-field ambiguity must be recorded without blocking remaining scenario coverage.","priority":"Low"}]": "<scenariojson JSON string>",




      "Add coverage for all missing scenarios TS_001-TS_007, TS_009, TS_011-TS_027; split any per-relevant-field edge coverage into atomic cases instead of one bundled case; align preconditions to each scenario instead of generic environment/setup text.": "<feedback string>",




   




    }




  },




  "confidence_score": <confidence score number>




}




```




Argument details:




- `form_data`:




  {




    "pipelineId": 169,




    "userInputs": {




      "[{"scenarioId":"TS_001","title":"Identify Eligibility, Assessment, and Maintenance Dates from inbound 834","acceptanceCriteriaRef":"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.","type":"Positive","description":"Validate that inbound EDI 834 processing identifies Eligibility Date from Loop 2000 DTP*356/DTP*348, Assessment Date from Loop 2300 HD03, and Maintenance Date from DTP*303 for transaction effective date evaluation.","priority":"High"},{"scenarioId":"TS_002","title":"Identify first occurrence when multiple date values are received","acceptanceCriteriaRef":"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.","type":"Edge","description":"Validate that when multiple inbound date occurrences are present, the first applicable date is identified and used per technical guidance.","priority":"High"},{"scenarioId":"TS_003","title":"Handle missing required date elements during date identification","acceptanceCriteriaRef":"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.","type":"Negative","description":"Validate that inbound processing flags a date identification gap when one or more of Eligibility Date, Assessment Date, or Maintenance Date required for rule evaluation are missing from the 834.","priority":"High"},{"scenarioId":"TS_004","title":"Populate Facets transaction effective date with identified Eligibility Date","acceptanceCriteriaRef":"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).","type":"Positive","description":"Validate that the identified Eligibility Date can be populated into the Facets transaction effective date field.","priority":"High"},{"scenarioId":"TS_005","title":"Populate Facets transaction effective date with identified Assessment Date","acceptanceCriteriaRef":"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).","type":"Positive","description":"Validate that the identified Assessment Date can be populated into the Facets transaction effective date field.","priority":"High"},{"scenarioId":"TS_006","title":"Populate Facets transaction effective date with identified Maintenance Date","acceptanceCriteriaRef":"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).","type":"Positive","description":"Validate that the identified Maintenance Date can be populated into the Facets transaction effective date field when selected by business rules.","priority":"High"},{"scenarioId":"TS_007","title":"Prevent unsupported date population to Facets transaction effective date","acceptanceCriteriaRef":"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).","type":"Negative","description":"Validate that Facets transaction effective date is not populated from any inbound date other than the identified Eligibility Date, Assessment Date, or Maintenance Date.","priority":"Medium"},{"scenarioId":"TS_008","title":"Use Eligibility Date for future new enrollment regardless of Assessment Date","acceptanceCriteriaRef":"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.","type":"Positive","description":"Validate that for an inbound new enrollment where the member eligibility span has not yet begun, the transaction effective date in Facets is populated with the Eligibility Date even when Assessment Date differs.","priority":"High"},{"scenarioId":"TS_009","title":"Use Eligibility Date when future eligibility and Assessment Date is earlier","acceptanceCriteriaRef":"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.","type":"Edge","description":"Validate that for future eligibility spans the Eligibility Date is used as transaction effective date when Assessment Date is earlier than the Eligibility Date.","priority":"High"},{"scenarioId":"TS_010","title":"Do not use Assessment or Maintenance Date for future eligibility enrollment","acceptanceCriteriaRef":"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.","type":"Negative","description":"Validate that for a member whose eligibility span has not yet begun, Assessment Date and Maintenance Date are not used as the transaction effective date.","priority":"High"},{"scenarioId":"TS_011","title":"Use Assessment Date when current eligibility exists and Assessment Date changes","acceptanceCriteriaRef":"AC4 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.","type":"Positive","description":"Validate that when the member eligibility span has already begun and the inbound Assessment Date changes, the transaction effective date in Facets is populated with the Assessment Date.","priority":"High"},{"scenarioId":"TS_012","title":"Use changed Assessment Date for current eligibility regardless of Eligibility Date value","acceptanceCriteriaRef":"AC4 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.","type":"Edge","description":"Validate that for current eligibility the changed Assessment Date is selected as transaction effective date even when the Eligibility Date remains unchanged or differs.","priority":"High"},{"scenarioId":"TS_013","title":"Do not use Maintenance Date when current eligibility Assessment Date changed","acceptanceCriteriaRef":"AC4 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.","type":"Negative","description":"Validate that Maintenance Date is not used as the transaction effective date when current eligibility exists and the Assessment Date has changed.","priority":"High"},{"scenarioId":"TS_014","title":"Use Assessment Date when only Assessment Date changes and relevant fields remain unchanged","acceptanceCriteriaRef":"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.","type":"Positive","description":"Validate that when Assessment Date changes and Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, and Pregnancy remain unchanged, the Assessment Date populates as the transaction effective date.","priority":"High"},{"scenarioId":"TS_015","title":"Maintain relevant field values when only Assessment Date changes","acceptanceCriteriaRef":"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.","type":"Positive","description":"Validate that relevant field values are preserved in Facets when Assessment Date changes but no relevant field change is received.","priority":"High"},{"scenarioId":"TS_016","title":"Detect relevant field change and avoid AC5 path","acceptanceCriteriaRef":"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.","type":"Negative","description":"Validate that AC5 logic is not applied when any relevant field among Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy has changed along with Assessment Date.","priority":"High"},{"scenarioId":"TS_017","title":"Use Eligibility Date for future eligibility with relevant field changes and unchanged Assessment Date","acceptanceCriteriaRef":"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.","type":"Positive","description":"Validate that when eligibility has not yet begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with the Eligibility Date.","priority":"High"},{"scenarioId":"TS_018","title":"Apply Eligibility Date for each relevant field change before eligibility start","acceptanceCriteriaRef":"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.","type":"Edge","description":"Validate that Eligibility Date is used as transaction effective date when any single relevant field change is received before eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.","priority":"High"},{"scenarioId":"TS_019","title":"Do not use Maintenance Date before eligibility start when Assessment Date is unchanged","acceptanceCriteriaRef":"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.","type":"Negative","description":"Validate that Maintenance Date is not used as the transaction effective date when relevant field changes are received before eligibility start and Assessment Date is unchanged.","priority":"High"},{"scenarioId":"TS_020","title":"Use Maintenance Date for current eligibility with relevant field changes and unchanged Assessment Date","acceptanceCriteriaRef":"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.","type":"Positive","description":"Validate that when eligibility has already begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with Maintenance Date DTP*303.","priority":"High"},{"scenarioId":"TS_021","title":"Apply Maintenance Date for each relevant field change after eligibility start","acceptanceCriteriaRef":"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.","type":"Edge","description":"Validate that Maintenance Date is used as transaction effective date when any single relevant field change is received after eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.","priority":"High"},{"scenarioId":"TS_022","title":"Do not use Eligibility Date for current eligibility relevant field changes when Assessment Date is unchanged","acceptanceCriteriaRef":"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.","type":"Negative","description":"Validate that Eligibility Date is not used as the transaction effective date when relevant field changes are received after eligibility start and Assessment Date is unchanged.","priority":"High"},{"scenarioId":"TS_023","title":"Maintenance Date used only in explicitly allowed scenario","acceptanceCriteriaRef":"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.","type":"Positive","description":"Validate that Maintenance Date is used only for inbound changes to relevant fields when eligibility has already begun and Assessment Date has not changed.","priority":"High"},{"scenarioId":"TS_024","title":"Prevent Maintenance Date usage for new enrollment and Assessment Date change scenarios","acceptanceCriteriaRef":"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.","type":"Negative","description":"Validate that Maintenance Date is not used for new enrollments, future eligibility updates, or scenarios where Assessment Date has changed.","priority":"High"},{"scenarioId":"TS_025","title":"Regression coverage for mixed inbound combinations of dates and relevant field changes","acceptanceCriteriaRef":"QA Regression - Test inbound 834 files with varying combinations of Eligibility Date, Assessment Date changes, and relevant field changes to verify correct transaction effective date population.","type":"Edge","description":"Validate correct transaction effective date selection across mixed inbound combinations of future eligibility, current eligibility, Assessment Date changes, and relevant field changes in repeated 2000 and 2300 loop occurrences.","priority":"High"},{"scenarioId":"TS_026","title":"Verify no finance-impacting regression from effective date logic update","acceptanceCriteriaRef":"QA Regression - Verify no change in capitation calculations and accurate reporting for finance team.","type":"Positive","description":"Validate that the updated inbound transaction effective date logic does not introduce capitation calculation mismatches or finance reporting inaccuracies downstream.","priority":"Medium"},{"scenarioId":"TS_027","title":"Flag knowledge gap when Assessment Date source conflicts with acceptance criteria wording","acceptanceCriteriaRef":"AC1-AC7 - Technical Notes and Acceptance Criteria alignment","type":"Edge","description":"Validate rule execution while flagging that technical notes identify Assessment Date at Loop 2300 HD03 and acceptance criteria reference date-based logic, so any source-field ambiguity must be recorded without blocking remaining scenario coverage.","priority":"Low"}]": "<INSERT the EXACT parsed value of the input `scenariojson` field. Do NOT regenerate it, reconstruct it, infer it, summarize it, or recreate it from memory. Copy the parsed JSON value directly and unchanged. The value passed to the tool MUST be byte-for-byte identical to the parsed input. If the exact parsed value is unavailable, do NOT substitute another value or placeholder.>",




      "Add coverage for all missing scenarios TS_001-TS_007, TS_009, TS_011-TS_027; split any per-relevant-field edge coverage into atomic cases instead of one bundled case; align preconditions to each scenario instead of generic environment/setup text.": "<insert the exact feedback generated above >"




    }




  }




- `confidence_score`: `<confidence score>`  ← TOP-LEVEL argument, a sibling of `form_data`, NOT nested inside it. Do NOT add `confidence_score` anywhere inside `form_data` or `userInputs`.




Keep the pipeline id constant at 169. Do NOT include `priority` in `form_data` — the tool sets it itself.




The `scenariojson` value passed here MUST be byte-for-byte identical to the scenarios you received in your input (which originated from the EDI 834 Inbound Test Scenario Generator).




# Rules




- "strengths" and "gaps" must be `[]` (empty array) if none — never null.




- "feedback" must always be present and specific enough that a generator with no other context could act on it directly (it is fed back verbatim on rework rounds).




- Do NOT write replacement test cases yourself — only judge and describe what's wrong.




- If `testcases` is empty or clearly not a test-case table, set confidence=0, approved=false, and explain in feedback.




- NEVER substitute the scenarios with a placeholder, summary, description, another agent's name, an empty array, or a regenerated version.




 




The ONLY valid source for `scenariojson` is the parsed input JSON.




 




The same parsed `scenarios` object MUST be copied unchanged into:




- the JSON output payload, and




- the REST API Form Data Caller tool arguments.




 




Never recreate the scenarios from memory or from your own reasoning.




- `confidence_score` is ALWAYS a top-level tool argument, a sibling of `form_data`. Never nest it inside `form_data` or `userInputs`.

This is the expected criteria for your final answer: Expected Output *
A single JSON object: {confidence, approved, feedback, strengths[], gaps[]}
Define the final deliverable and format (e.g., JSON with 3 fields, or a polished email draft).-
Also preserve the testcases coming from the previous agent and display in the output
you MUST return the actual complete content as the final answer, not a summary.

This is the context you're working with:
## Changes Made This Round
- Added explicit traceability fields for each test case: every case includes `ScenarioId` and `AcceptanceCriteriaRef`.
- Applied atomicity by limiting output to 2 focused functional test cases, each validating one primary behavior only.
- Updated preconditions to be scenario-specific with AR PASSE LOB, exact inbound file purpose, exact staging/archive paths, and member state.
- Made expected results measurable with exact segment references, exact TM status checks, exact archive path, and exact SQL validation statements.
- Incorporated missing-scenario coverage partially within the allowed maximum of 2 test cases by prioritizing highest-risk AC1 and AC3 scenarios from the rework notes.
- Used knowledge-base-derived process patterns: MI HAP/834 inbound staging, Edifecs TM validation, archive validation, Facets verification flow, DB server `crt_72.sql.caresource.corp\crt_72`, and MELC/crosswalk checks.
- Aligned steps to detailed manual-test style and included server/database/query references in the step descriptions.

{
  "testcases": "| ScenarioId | AcceptanceCriteriaRef | Name | Id | Attachments | Status | Test Case Type | Description | Precondition | Test Step # | Test Step Description | Test Step Expected Result | Test Step Attachment |\n|---|---|---|---|---|---|---|---|---|---:|---|---|---|\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 1 | Create a copy of a valid MI HAP inbound 834 sample file for AR PASSE and retain the original envelope structure (ISA/GS/ST/SE/GE/IEA) while making the file name unique per companion-guide-based naming convention used in existing inbound files. | A unique AR PASSE-compatible 834 file is prepared and its filename is distinct from prior submissions while preserving valid 834 envelope structure. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 2 | In Loop 2000 of the test file, populate `DTP*356*D8*20250101~`; if implementation also accepts `DTP*348`, populate `DTP*348*D8*20250101~` with the same date to avoid ambiguity for this positive scenario. | The file contains a valid eligibility/effective date segment in Loop 2000 with date value `20250101`. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 3 | In Loop 2300, populate the assessment source field per technical note by setting `HD03` to `ASMT20250115` and ensure the member maintenance detail remains syntactically valid. | The file contains Loop 2300 `HD03=ASMT20250115` and the 2300 loop remains structurally valid. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 4 | Populate maintenance date segment `DTP*303*D8*20241220~` in the applicable maintenance loop for the same member transaction. | The file contains a valid maintenance date segment with value `20241220`. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 5 | Update control numbers consistently in ISA13, GS06, ST02, SE02, GE02, and IEA02 so the file is uniquely processable and internally balanced. | Envelope control numbers are unique and balanced; segment counts and trailer references are internally consistent. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 6 | Save the completed file and place it in the NAS inbound staging folder `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`. | The file is present in `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound` with the expected unique filename. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 7 | Wait for Edifecs pickup and then log in to CRT TM UI at `https://edifecstm-crt.caresource.corp:8443/tm/logon/logon.jsp` using authorized credentials. | CRT TM login succeeds and the user lands on the transmission search page. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 8 | Under Transmissions, select `Last 24 Hours (Batch)` and filter by transaction type `834` or trading partner `MI HAP`, then search for the submitted filename. | The submitted file appears in TM search results under the last 24 hours batch view. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 9 | Open the transmission record and verify the batch processed successfully with no fatal validation errors and that policy unit delivery is completed/successful. | TM shows the file processed successfully; policy unit delivery status is `Completed/Success` or equivalent successful completion state with no blocking error on the transaction. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 10 | Open the transaction attachments/canonical payload in TM and inspect the member transaction to confirm the inbound segments include `DTP*356` or `DTP*348`, `HD03`, and `DTP*303` with the exact values loaded from the file. | Canonical or transaction detail view shows the exact inbound values `20250101`, `ASMT20250115`, and `20241220` for the corresponding source fields. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 11 | Verify the processed physical file is archived to `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`. | The exact submitted filename exists in `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 12 | Connect to SQL Server `crt_72.sql.caresource.corp\\crt_72` using SSMS and open a new query window for validation. | SQL connection to `crt_72.sql.caresource.corp\\crt_72` succeeds and a query window is available. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 13 | Run the crosswalk validation query: `select * from CMC_MELC_LSTY_CD (nolock) where MEME_CK = (select MEME_CK from FACPRDDB.dbo.CMC_MEME_MEMBER where MEME_SSN='{{AR_PASSE_SSN_01}}');` | Query returns 0 rows matching an unexpected crosswalk condition for this scenario, satisfying the requirement that data should not match disallowed crosswalk criteria. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 14 | Run MELC validation query: `select * from FACPRDDB.dbo.CMC_MELC_LSTY_CD (nolock) where MEME_CK = (select MEME_CK from FACPRDDB.dbo.CMC_MEME_MEMBER where MEME_SSN='{{AR_PASSE_SSN_01}}');` and review whether any error/listing row was created due to incorrect data. | No new MELC row attributable to incorrect inbound data is created for `{{AR_PASSE_SSN_01}}`. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 15 | Launch Facets in CRT, open the configured product database, navigate to Subscriber/Family, and search by SSN `{{AR_PASSE_SSN_01}}` or subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`. | The AR PASSE member record opens successfully in Facets for the submitted subscriber. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 16 | Review the processed transaction details available to the member and confirm the transaction completed without member-intake hold or policy-unit error. | No unresolved intake hold or policy unit error is present for the processed transaction. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 17 | Document the exact source-to-value mapping observed during validation: Eligibility Date from `DTP*356/DTP*348=20250101`, Assessment source from `HD03=ASMT20250115`, and Maintenance Date from `DTP*303=20241220`. | Test evidence records the three exact inbound source values and confirms they were identifiable in processing artifacts. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 18 | Capture screenshots or exported evidence from TM search result, TM transaction detail/canonical view, archive folder listing, and SQL result sets. | Evidence set contains timestamped proof of successful processing, archive placement, and SQL validation results. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 19 | Compare all observed results against AC1 and confirm no date-identification gap exists for the three required date sources in this positive scenario. | AC1 passes: all three required date sources are present, identifiable, and processed without error. | None |\n| TS_001 | AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date. | Verify inbound 834 identifies Eligibility, Assessment, and Maintenance dates for AR PASSE transaction effective date evaluation | TC_001 | None | Draft | Positive | Validate that AR PASSE inbound 834 processing identifies Eligibility Date from Loop 2000 DTP*356 or DTP*348, Assessment Date from Loop 2300 HD03 per technical note, and Maintenance Date from DTP*303, and makes those values available for downstream transaction effective date logic. | AR PASSE LOB test member exists in CRT with known SSN `{{AR_PASSE_SSN_01}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_01}}`; create one MI HAP inbound 834 test file using companion-guide naming convention pattern copied from a valid production-like sample and made unique by changing numeric control portions; file contains one member transaction with Loop 2000 DTP*356=`20250101`, Loop 2000 DTP*348=`20250101`, Loop 2300 HD03=`ASMT20250115`, and DTP*303=`20241220`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`; no intentional data-quality errors are included in the file. | 20 | Mark the test case outcome and attach the evidence package for downstream review. | Test case is ready for audit with pass/fail decision, traceability, and evidence attached. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 1 | Copy a valid MI HAP inbound 834 sample for AR PASSE and create a unique filename by changing the numeric uniqueness portion while preserving the established inbound naming pattern. | A uniquely named AR PASSE-compatible inbound 834 file is prepared for submission. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 2 | Populate the future eligibility date in Loop 2000 as `DTP*356*D8*20251201~` and, if required by implementation, also populate `DTP*348*D8*20251201~`. | The file contains future eligibility date `20251201` in the accepted eligibility date source segment(s). | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 3 | Populate a different assessment source value in Loop 2300 by setting `HD03=ASMT20251115` so the assessment-related value is earlier than the future eligibility date. | The file contains `HD03=ASMT20251115`, which differs from the future eligibility date. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 4 | Populate maintenance date `DTP*303*D8*20251120~`, also earlier than the future eligibility date, to prove it is not selected for this scenario. | The file contains maintenance date `20251120`, which differs from and is earlier than `20251201`. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 5 | Update ISA/GS/ST control numbers and corresponding GE/IEA/SE references so the file is unique and balanced for processing. | Envelope control numbers are unique and all header/trailer references reconcile correctly. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 6 | Place the file in `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound` and confirm the file is visible in the folder. | The file is present in the inbound staging folder with the expected unique filename. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 7 | Log in to CRT TM UI at `https://edifecstm-crt.caresource.corp:8443/tm/logon/logon.jsp`. | CRT TM login succeeds. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 8 | Under Transmissions, select `Last 24 Hours (Batch)`, filter by transaction `834` or trading partner `MI HAP`, and locate the submitted file. | The submitted file is returned in TM search results. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 9 | Open the transmission and verify successful processing with no fatal validation errors and successful policy unit delivery. | TM shows successful processing and policy unit delivery completed successfully. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 10 | Open transaction details/canonical payload and confirm the inbound values are present exactly as submitted: eligibility `20251201`, assessment source `ASMT20251115`, maintenance `20251120`. | Canonical or transaction detail view shows the exact submitted values for all three source fields. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 11 | Verify the processed file is archived to `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`. | The exact submitted filename exists in the archive folder. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 12 | Connect to SQL Server `crt_72.sql.caresource.corp\\crt_72` and open a new query window. | SQL connection succeeds. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 13 | Run query to retrieve member key and subscriber key: `select MEME_CK, SBSB_CK, MEME_SSN from FACPRDDB.dbo.CMC_MEME_MEMBER where MEME_SSN='{{AR_PASSE_SSN_02}}';` | Query returns exactly one member row for `{{AR_PASSE_SSN_02}}`. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 14 | Run eligibility query: `SELECT * FROM FACPRDDB.dbo.CMC_SBEL_ELIG_ENT SBEL JOIN FACPRDDB.dbo.CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBEL.SBSB_CK WHERE MEME.MEME_SSN='{{AR_PASSE_SSN_02}}' ORDER BY SBEL_EFF_DT;` | At least one eligibility row exists for the member with effective date `2025-12-01` or `20251201` depending on DB display format. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 15 | Run processed eligibility query: `SELECT * FROM FACPRDDB.dbo.CMC_MEPE_PRCS_ELIG MEPE JOIN FACPRDDB.dbo.CMC_MEME_MEMBER MEME ON MEME.MEME_CK = MEPE.MEME_CK WHERE MEME.MEME_SSN='{{AR_PASSE_SSN_02}}' ORDER BY MEPE_EFF_DT;` | Processed eligibility rows include an effective date row beginning `2025-12-01`/`20251201` for the future enrollment. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 16 | Launch Facets CRT, open Subscriber/Family, and search for subscriber `{{AR_PASSE_SUBSCRIBER_02}}` or SSN `{{AR_PASSE_SSN_02}}`. | The member/subscriber record opens in Facets. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 17 | Review the transaction effective date displayed/derived in Facets transaction context for the processed enrollment and compare it to the three inbound source values. | The transaction effective date equals `2025-12-01`/`20251201` and does not equal assessment-related `20251115` or maintenance `20251120`. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 18 | Run crosswalk validation query `select * from CMC_MELC_LSTY_CD (nolock) where MEME_CK = (select MEME_CK from FACPRDDB.dbo.CMC_MEME_MEMBER where MEME_SSN='{{AR_PASSE_SSN_02}}');` and confirm no disallowed crosswalk row is created. | Query returns no unexpected crosswalk match rows for the member. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 19 | Capture evidence from TM, archive folder, Facets transaction view, and SQL result sets showing the selected effective date equals the eligibility date. | Evidence package clearly shows transaction effective date `20251201` and excludes `20251115` and `20251120` as selected values. | None |\n| TS_008 | AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date. | Verify future new enrollment uses Eligibility Date as Facets transaction effective date for AR PASSE | TC_002 | None | Draft | Positive | Validate that for an AR PASSE inbound new enrollment where the member eligibility span has not yet begun, Facets transaction effective date is populated from Eligibility Date `DTP*356/DTP*348` and not from differing Assessment or Maintenance dates. | AR PASSE LOB future-enrollment test member exists or is creatable in CRT with SSN `{{AR_PASSE_SSN_02}}` and subscriber ID `{{AR_PASSE_SUBSCRIBER_02}}`; member has no active eligibility span as of current processing date and the inbound eligibility start is future-dated `20251201`; create one MI HAP inbound 834 file using the established companion-guide-based naming pattern with unique control numbers; file contains Loop 2000 `DTP*356*D8*20251201~` and/or `DTP*348*D8*20251201~`, Loop 2300 `HD03=ASMT20251115`, and `DTP*303*D8*20251120~`; file is staged to `\\\\daycrtappfs01\\EdifecsSTRoot\\834\\Inbound`; expected archive path is `\\\\daycrtappfs01\\EdifecsSTArchive\\834\\Inbound\\State_of_MI`; DB validation is performed on `crt_72.sql.caresource.corp\\crt_72`. | 20 | Record final outcome and pass the completed test case with scenariojson traceability to the next agent. | Test case is audit-ready, mapped to TS_008/AC3, and ready for downstream consumption. | None |",
  "scenariojson": "[{\"scenarioId\":\"TS_001\",\"title\":\"Identify Eligibility, Assessment, and Maintenance Dates from inbound 834\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Positive\",\"description\":\"Validate that inbound EDI 834 processing identifies Eligibility Date from Loop 2000 DTP*356/DTP*348, Assessment Date from Loop 2300 HD03, and Maintenance Date from DTP*303 for transaction effective date evaluation.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_002\",\"title\":\"Identify first occurrence when multiple date values are received\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Edge\",\"description\":\"Validate that when multiple inbound date occurrences are present, the first applicable date is identified and used per technical guidance.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_003\",\"title\":\"Handle missing required date elements during date identification\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Negative\",\"description\":\"Validate that inbound processing flags a date identification gap when one or more of Eligibility Date, Assessment Date, or Maintenance Date required for rule evaluation are missing from the 834.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_004\",\"title\":\"Populate Facets transaction effective date with identified Eligibility Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Eligibility Date can be populated into the Facets transaction effective date field.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_005\",\"title\":\"Populate Facets transaction effective date with identified Assessment Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Assessment Date can be populated into the Facets transaction effective date field.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_006\",\"title\":\"Populate Facets transaction effective date with identified Maintenance Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Maintenance Date can be populated into the Facets transaction effective date field when selected by business rules.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_007\",\"title\":\"Prevent unsupported date population to Facets transaction effective date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Negative\",\"description\":\"Validate that Facets transaction effective date is not populated from any inbound date other than the identified Eligibility Date, Assessment Date, or Maintenance Date.\",\"priority\":\"Medium\"},{\"scenarioId\":\"TS_008\",\"title\":\"Use Eligibility Date for future new enrollment regardless of Assessment Date\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that for an inbound new enrollment where the member eligibility span has not yet begun, the transaction effective date in Facets is populated with the Eligibility Date even when Assessment Date differs.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_009\",\"title\":\"Use Eligibility Date when future eligibility and Assessment Date is earlier\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that for future eligibility spans the Eligibility Date is used as transaction effective date when Assessment Date is earlier than the Eligibility Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_010\",\"title\":\"Do not use Assessment or Maintenance Date for future eligibility enrollment\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that for a member whose eligibility span has not yet begun, Assessment Date and Maintenance Date are not used as the transaction effective date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_011\",\"title\":\"Use Assessment Date when current eligibility exists and Assessment Date changes\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when the member eligibility span has already begun and the inbound Assessment Date changes, the transaction effective date in Facets is populated with the Assessment Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_012\",\"title\":\"Use changed Assessment Date for current eligibility regardless of Eligibility Date value\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that for current eligibility the changed Assessment Date is selected as transaction effective date even when the Eligibility Date remains unchanged or differs.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_013\",\"title\":\"Do not use Maintenance Date when current eligibility Assessment Date changed\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used as the transaction effective date when current eligibility exists and the Assessment Date has changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_014\",\"title\":\"Use Assessment Date when only Assessment Date changes and relevant fields remain unchanged\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Positive\",\"description\":\"Validate that when Assessment Date changes and Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, and Pregnancy remain unchanged, the Assessment Date populates as the transaction effective date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_015\",\"title\":\"Maintain relevant field values when only Assessment Date changes\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Positive\",\"description\":\"Validate that relevant field values are preserved in Facets when Assessment Date changes but no relevant field change is received.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_016\",\"title\":\"Detect relevant field change and avoid AC5 path\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Negative\",\"description\":\"Validate that AC5 logic is not applied when any relevant field among Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy has changed along with Assessment Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_017\",\"title\":\"Use Eligibility Date for future eligibility with relevant field changes and unchanged Assessment Date\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when eligibility has not yet begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with the Eligibility Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_018\",\"title\":\"Apply Eligibility Date for each relevant field change before eligibility start\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that Eligibility Date is used as transaction effective date when any single relevant field change is received before eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_019\",\"title\":\"Do not use Maintenance Date before eligibility start when Assessment Date is unchanged\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used as the transaction effective date when relevant field changes are received before eligibility start and Assessment Date is unchanged.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_020\",\"title\":\"Use Maintenance Date for current eligibility with relevant field changes and unchanged Assessment Date\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when eligibility has already begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with Maintenance Date DTP*303.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_021\",\"title\":\"Apply Maintenance Date for each relevant field change after eligibility start\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that Maintenance Date is used as transaction effective date when any single relevant field change is received after eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_022\",\"title\":\"Do not use Eligibility Date for current eligibility relevant field changes when Assessment Date is unchanged\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Eligibility Date is not used as the transaction effective date when relevant field changes are received after eligibility start and Assessment Date is unchanged.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_023\",\"title\":\"Maintenance Date used only in explicitly allowed scenario\",\"acceptanceCriteriaRef\":\"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.\",\"type\":\"Positive\",\"description\":\"Validate that Maintenance Date is used only for inbound changes to relevant fields when eligibility has already begun and Assessment Date has not changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_024\",\"title\":\"Prevent Maintenance Date usage for new enrollment and Assessment Date change scenarios\",\"acceptanceCriteriaRef\":\"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used for new enrollments, future eligibility updates, or scenarios where Assessment Date has changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_025\",\"title\":\"Regression coverage for mixed inbound combinations of dates and relevant field changes\",\"acceptanceCriteriaRef\":\"QA Regression - Test inbound 834 files with varying combinations of Eligibility Date, Assessment Date changes, and relevant field changes to verify correct transaction effective date population.\",\"type\":\"Edge\",\"description\":\"Validate correct transaction effective date selection across mixed inbound combinations of future eligibility, current eligibility, Assessment Date changes, and relevant field changes in repeated 2000 and 2300 loop occurrences.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_026\",\"title\":\"Verify no finance-impacting regression from effective date logic update\",\"acceptanceCriteriaRef\":\"QA Regression - Verify no change in capitation calculations and accurate reporting for finance team.\",\"type\":\"Positive\",\"description\":\"Validate that the updated inbound transaction effective date logic does not introduce capitation calculation mismatches or finance reporting inaccuracies downstream.\",\"priority\":\"Medium\"},{\"scenarioId\":\"TS_027\",\"title\":\"Flag knowledge gap when Assessment Date source conflicts with acceptance criteria wording\",\"acceptanceCriteriaRef\":\"AC1-AC7 - Technical Notes and Acceptance Criteria alignment\",\"type\":\"Edge\",\"description\":\"Validate rule execution while flagging that technical notes identify Assessment Date at Loop 2300 HD03 and acceptance criteria reference date-based logic, so any source-field ambiguity must be recorded without blocking remaining scenario coverage.\",\"priority\":\"Low\"}]"
}
### 📝 Task Started  
**Agent:** Test Case Reviewer LLM as a Judge Test4 wf2
**Expected Output:**  
Expected Output *
A single JSON object: {confidence, approved, feedback, strengths[], gaps[]}
Define the final deliverable and format (e.g., JSON with 3 fields, or a polished email draft).-
Also preserve the testcases coming from the previous agent and display in the output
**Description:**  
# Role




You are an independent QA reviewer. You did NOT write these test cases. Judge them critically and honestly. Output ONLY a JSON verdict — no prose, no markdown, no code fences.




# Input




Input will be coming from the previous agent, which is a JSON object having test cases. Parse it first. It has exactly two fields:




- **testcases** — the generated test cases as a MARKDOWN TABLE. Columns are:




  Name | Id | Attachments | Status | Test Case Type | Description | Precondition | Test Step # | Test Step Description | Test Step Expected Result | Test Step Attachment




  Each test case has an Id like `TC_MIHAP_001` (starts with "TC", ends in a number). A single test case spans multiple rows — one row per test step (the Id/Name repeat or are blank on continuation rows). "Test Case Type" is one of Positive, Negative, Edge.




- **scenariojson** — the scenario list each test case should map to (the previous agent emits this field as `scenariojson`, NOT `scenarios`). Each scenario object has: `scenarioId` (e.g. `TS_001`), `title`, `acceptanceCriteriaRef`, `type`, `description`, `priority`. There is NO separate story, epic, or preconditions input. Trace test cases using the `scenariojson` list only (specifically each scenario's `scenarioId` and `acceptanceCriteriaRef`).




**IMPORTANT — retain scenarios verbatim (CRITICAL):**




 




Immediately after parsing the input JSON, treat the value of the `scenariojson` field as an IMMUTABLE object.




 




The `scenariojson` array is the single source of truth and MUST NEVER be reconstructed, regenerated, reformatted, summarized, inferred, or recreated from memory.




 




For both:




- the JSON output payload, and




- the REST API Form Data Caller tool invocation,




 




copy the EXACT parsed `scenariojson` value from the input without making ANY modification.




 




The copied value MUST preserve:




- every scenario object,




- every field,




- field order,




- array order,




- values,




- whitespace inside string values,




- escaping,




- and all JSON content exactly as received.




 




NEVER:




- replace it with a placeholder,




- replace it with the name of another agent,




- replace it with "...",




- replace it with an empty array,




- regenerate it from your reasoning,




- omit it because it was already reviewed.




 




If you cannot reproduce the exact parsed value, STOP and treat it as an error instead of inventing or reconstructing a replacement.




# Review Checklist (work through each point)




1. **SCENARIO COVERAGE** — Does every scenario in `scenariojson` have at least one corresponding test case in the table? Flag any scenario (by `scenarioId`) with zero test cases. More than one test case per scenario is fine ONLY if the scenario genuinely bundles independent mechanisms and each test case covers a distinct one — flag it as a gap if the split looks arbitrary.




2. **ATOMICITY** — This is a primary check. Does any test case bundle several DIFFERENT independent mechanisms/rules into one test case via "repeat steps N-M with X, then with Y, then with Z" prose? That is not proper parameterization — if one sub-part fails, the tester cannot tell which mechanism broke. Flag it explicitly, naming the Id (e.g. `TC_MIHAP_001`) and which distinct mechanisms it improperly bundled; it should have been split into separate test cases. This is DIFFERENT from a legitimate data-driven test case (the SAME single mechanism across several input values) — that is fine and must NOT be flagged.




3. **TRACEABILITY** — Does each test case clearly map to a real scenario in `scenariojson` (by `scenarioId` and/or the scenario's `acceptanceCriteriaRef`)? Flag any test case that maps to no scenario, or cites an acceptance criterion that does not appear in any scenario.




4. **PRECONDITION RELEVANCE** — For each test case's "Precondition" column, does the text actually relate to what that test case is testing? Flag any precondition that looks generic/copied and ignores what the scenario clearly needs, or is empty when the scenario plainly requires one.




5. **NEGATIVE / EDGE COVERAGE** — Given the scenario types (Positive/Negative/Edge), are the corresponding negative-path and edge/boundary test cases actually present, not just the happy path? Flag Negative/Edge scenarios that only got Positive coverage.




6. **CLARITY** — Are the Test Step Description and Test Step Expected Result cells concrete and executable, or vague ("verify it works")? Flag steps with an empty description or empty expected result.




# Scoring




After reviewing all 6 points, assign:




- **confidence**: 0-100 (how confident you are this set is complete, correctly grounded, and correct)




  - **90-100**: excellent coverage, relevant preconditions, well-traced to scenarios, clear steps, no gaps, every test case atomic (no bundled-mechanism "repeat steps" cases)




  - **70-89**: solid coverage, minor gaps or a little vague, but traceability, precondition relevance, and atomicity are all correct




  - **50-69**: real gaps — missing negative/edge cases, weak traceability, any precondition mismatch, OR any test case improperly bundling independent mechanisms via "repeat steps" prose (any one of these alone keeps this below 70)




  - **0-49**: poor coverage, ungrounded, or barely related to the scenarios




- **approved**: true if confidence >= 80, false otherwise




# Condition for Output




If approved is true, pass the input you received as it is as your output. If the confidence score is equal to or above the threshold, add the testcases along with the original output; otherwise, give the original output alone.




[MUST] - Always preserve the test scenarios verbatim in the JSON output payload — copy the exact `scenariojson` array you parsed from your input.




## Output Format (approved = true)




confidence score:<number 1-100>




| ScenarioId | AcceptanceCriteriaRef | Name | Id | Attachments | Status | Test Case Type | Description | Precondition | Test Step # | Test Step Description | Test Step Expected Result | Test Step Attachment |




If approved is false, pass the scenarios from the previous agent as your output with the format below.




## Output Format (approved = false)




```json




{




  "confidence": <number 0-100>,




  "approved": true | false,




  "feedback": "<one concise line a generator could act on: exactly what to fix or add>",




  "strengths": ["<what's good about this set, 0-3 items>"],




  "gaps": ["<specific missing case, precondition mismatch, or clarity issue, 0-5 items — be concrete: 'tc_mihap_003 states db access but tests file naming only' not 'precondition could be better'>"],




  "scenariojson": <the EXACT `scenariojson` array you parsed from your input — the full JSON array of scenario objects, copied verbatim; NOT a placeholder, name, or summary>




}




```




 




Before producing ANY output, perform this mandatory validation:




 




1. Confirm that the `scenariojson` value you are about to output is identical to the `scenariojson` value from the parsed input.




2. Confirm that the `scenariojson` value used in the REST API tool call is identical to the parsed input.




3. Never derive, regenerate, or summarize the scenarios from your reasoning. Always copy the original parsed JSON value.




# Tool Call




Call Tool "REST API Form Data Caller test" with EXACTLY TWO top-level arguments: `form_data` and `confidence_score`. These are SIBLINGS at the same level. `confidence_score` is its OWN separate argument — do NOT put it inside `form_data`, and do NOT put it inside `userInputs`.




The full arguments object MUST have this exact top-level shape:




```json




{




  "form_data": {




    "pipelineId": 169,




    "userInputs": {




      "tsInputJson": "<scenariojson JSON string>",




      "rvwFeedbackTxt": "<feedback string>",




   




    }




  },




  "confidence_score": <confidence score number>




}




```




Argument details:




- `form_data`:




  {




    "pipelineId": 169,




    "userInputs": {




      "tsInputJson": "<INSERT the EXACT parsed value of the input `scenariojson` field. Do NOT regenerate it, reconstruct it, infer it, summarize it, or recreate it from memory. Copy the parsed JSON value directly and unchanged. The value passed to the tool MUST be byte-for-byte identical to the parsed input. If the exact parsed value is unavailable, do NOT substitute another value or placeholder.>",




      "rvwFeedbackTxt": "<insert the exact feedback generated above >"




    }




  }




- `confidence_score`: `<confidence score>`  ← TOP-LEVEL argument, a sibling of `form_data`, NOT nested inside it. Do NOT add `confidence_score` anywhere inside `form_data` or `userInputs`.




Keep the pipeline id constant at 169. Do NOT include `priority` in `form_data` — the tool sets it itself.




The `scenariojson` value passed here MUST be byte-for-byte identical to the scenarios you received in your input (which originated from the EDI 834 Inbound Test Scenario Generator).




# Rules




- "strengths" and "gaps" must be `[]` (empty array) if none — never null.




- "feedback" must always be present and specific enough that a generator with no other context could act on it directly (it is fed back verbatim on rework rounds).




- Do NOT write replacement test cases yourself — only judge and describe what's wrong.




- If `testcases` is empty or clearly not a test-case table, set confidence=0, approved=false, and explain in feedback.




- NEVER substitute the scenarios with a placeholder, summary, description, another agent's name, an empty array, or a regenerated version.




 




The ONLY valid source for `scenariojson` is the parsed input JSON.




 




The same parsed `scenarios` object MUST be copied unchanged into:




- the JSON output payload, and




- the REST API Form Data Caller tool arguments.




 




Never recreate the scenarios from memory or from your own reasoning.




- `confidence_score` is ALWAYS a top-level tool argument, a sibling of `form_data`. Never nest it inside `form_data` or `userInputs`.
### 🛠️ Tool Initialized  
**Tool:** rest_api_form_data_caller  
**Agent:** Test Case Reviewer LLM as a Judge Test4 wf2
**Tool Arguments (JSON):**  
```json
{
  "form_data": {
    "pipelineId": 169,
    "userInputs": {
      "[{\"scenarioId\":\"TS_001\",\"title\":\"Identify Eligibility, Assessment, and Maintenance Dates from inbound 834\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Positive\",\"description\":\"Validate that inbound EDI 834 processing identifies Eligibility Date from Loop 2000 DTP*356/DTP*348, Assessment Date from Loop 2300 HD03, and Maintenance Date from DTP*303 for transaction effective date evaluation.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_002\",\"title\":\"Identify first occurrence when multiple date values are received\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Edge\",\"description\":\"Validate that when multiple inbound date occurrences are present, the first applicable date is identified and used per technical guidance.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_003\",\"title\":\"Handle missing required date elements during date identification\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Negative\",\"description\":\"Validate that inbound processing flags a date identification gap when one or more of Eligibility Date, Assessment Date, or Maintenance Date required for rule evaluation are missing from the 834.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_004\",\"title\":\"Populate Facets transaction effective date with identified Eligibility Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Eligibility Date can be populated into the Facets transaction effective date field.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_005\",\"title\":\"Populate Facets transaction effective date with identified Assessment Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Assessment Date can be populated into the Facets transaction effective date field.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_006\",\"title\":\"Populate Facets transaction effective date with identified Maintenance Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Maintenance Date can be populated into the Facets transaction effective date field when selected by business rules.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_007\",\"title\":\"Prevent unsupported date population to Facets transaction effective date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Negative\",\"description\":\"Validate that Facets transaction effective date is not populated from any inbound date other than the identified Eligibility Date, Assessment Date, or Maintenance Date.\",\"priority\":\"Medium\"},{\"scenarioId\":\"TS_008\",\"title\":\"Use Eligibility Date for future new enrollment regardless of Assessment Date\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that for an inbound new enrollment where the member eligibility span has not yet begun, the transaction effective date in Facets is populated with the Eligibility Date even when Assessment Date differs.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_009\",\"title\":\"Use Eligibility Date when future eligibility and Assessment Date is earlier\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that for future eligibility spans the Eligibility Date is used as transaction effective date when Assessment Date is earlier than the Eligibility Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_010\",\"title\":\"Do not use Assessment or Maintenance Date for future eligibility enrollment\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that for a member whose eligibility span has not yet begun, Assessment Date and Maintenance Date are not used as the transaction effective date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_011\",\"title\":\"Use Assessment Date when current eligibility exists and Assessment Date changes\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when the member eligibility span has already begun and the inbound Assessment Date changes, the transaction effective date in Facets is populated with the Assessment Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_012\",\"title\":\"Use changed Assessment Date for current eligibility regardless of Eligibility Date value\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that for current eligibility the changed Assessment Date is selected as transaction effective date even when the Eligibility Date remains unchanged or differs.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_013\",\"title\":\"Do not use Maintenance Date when current eligibility Assessment Date changed\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used as the transaction effective date when current eligibility exists and the Assessment Date has changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_014\",\"title\":\"Use Assessment Date when only Assessment Date changes and relevant fields remain unchanged\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Positive\",\"description\":\"Validate that when Assessment Date changes and Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, and Pregnancy remain unchanged, the Assessment Date populates as the transaction effective date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_015\",\"title\":\"Maintain relevant field values when only Assessment Date changes\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Positive\",\"description\":\"Validate that relevant field values are preserved in Facets when Assessment Date changes but no relevant field change is received.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_016\",\"title\":\"Detect relevant field change and avoid AC5 path\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Negative\",\"description\":\"Validate that AC5 logic is not applied when any relevant field among Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy has changed along with Assessment Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_017\",\"title\":\"Use Eligibility Date for future eligibility with relevant field changes and unchanged Assessment Date\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when eligibility has not yet begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with the Eligibility Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_018\",\"title\":\"Apply Eligibility Date for each relevant field change before eligibility start\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that Eligibility Date is used as transaction effective date when any single relevant field change is received before eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_019\",\"title\":\"Do not use Maintenance Date before eligibility start when Assessment Date is unchanged\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used as the transaction effective date when relevant field changes are received before eligibility start and Assessment Date is unchanged.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_020\",\"title\":\"Use Maintenance Date for current eligibility with relevant field changes and unchanged Assessment Date\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when eligibility has already begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with Maintenance Date DTP*303.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_021\",\"title\":\"Apply Maintenance Date for each relevant field change after eligibility start\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that Maintenance Date is used as transaction effective date when any single relevant field change is received after eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_022\",\"title\":\"Do not use Eligibility Date for current eligibility relevant field changes when Assessment Date is unchanged\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Eligibility Date is not used as the transaction effective date when relevant field changes are received after eligibility start and Assessment Date is unchanged.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_023\",\"title\":\"Maintenance Date used only in explicitly allowed scenario\",\"acceptanceCriteriaRef\":\"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.\",\"type\":\"Positive\",\"description\":\"Validate that Maintenance Date is used only for inbound changes to relevant fields when eligibility has already begun and Assessment Date has not changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_024\",\"title\":\"Prevent Maintenance Date usage for new enrollment and Assessment Date change scenarios\",\"acceptanceCriteriaRef\":\"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used for new enrollments, future eligibility updates, or scenarios where Assessment Date has changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_025\",\"title\":\"Regression coverage for mixed inbound combinations of dates and relevant field changes\",\"acceptanceCriteriaRef\":\"QA Regression - Test inbound 834 files with varying combinations of Eligibility Date, Assessment Date changes, and relevant field changes to verify correct transaction effective date population.\",\"type\":\"Edge\",\"description\":\"Validate correct transaction effective date selection across mixed inbound combinations of future eligibility, current eligibility, Assessment Date changes, and relevant field changes in repeated 2000 and 2300 loop occurrences.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_026\",\"title\":\"Verify no finance-impacting regression from effective date logic update\",\"acceptanceCriteriaRef\":\"QA Regression - Verify no change in capitation calculations and accurate reporting for finance team.\",\"type\":\"Positive\",\"description\":\"Validate that the updated inbound transaction effective date logic does not introduce capitation calculation mismatches or finance reporting inaccuracies downstream.\",\"priority\":\"Medium\"},{\"scenarioId\":\"TS_027\",\"title\":\"Flag knowledge gap when Assessment Date source conflicts with acceptance criteria wording\",\"acceptanceCriteriaRef\":\"AC1-AC7 - Technical Notes and Acceptance Criteria alignment\",\"type\":\"Edge\",\"description\":\"Validate rule execution while flagging that technical notes identify Assessment Date at Loop 2300 HD03 and acceptance criteria reference date-based logic, so any source-field ambiguity must be recorded without blocking remaining scenario coverage.\",\"priority\":\"Low\"}]": "[{\"scenarioId\":\"TS_001\",\"title\":\"Identify Eligibility, Assessment, and Maintenance Dates from inbound 834\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Positive\",\"description\":\"Validate that inbound EDI 834 processing identifies Eligibility Date from Loop 2000 DTP*356/DTP*348, Assessment Date from Loop 2300 HD03, and Maintenance Date from DTP*303 for transaction effective date evaluation.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_002\",\"title\":\"Identify first occurrence when multiple date values are received\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Edge\",\"description\":\"Validate that when multiple inbound date occurrences are present, the first applicable date is identified and used per technical guidance.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_003\",\"title\":\"Handle missing required date elements during date identification\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Negative\",\"description\":\"Validate that inbound processing flags a date identification gap when one or more of Eligibility Date, Assessment Date, or Maintenance Date required for rule evaluation are missing from the 834.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_004\",\"title\":\"Populate Facets transaction effective date with identified Eligibility Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Eligibility Date can be populated into the Facets transaction effective date field.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_005\",\"title\":\"Populate Facets transaction effective date with identified Assessment Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Assessment Date can be populated into the Facets transaction effective date field.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_006\",\"title\":\"Populate Facets transaction effective date with identified Maintenance Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Maintenance Date can be populated into the Facets transaction effective date field when selected by business rules.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_007\",\"title\":\"Prevent unsupported date population to Facets transaction effective date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Negative\",\"description\":\"Validate that Facets transaction effective date is not populated from any inbound date other than the identified Eligibility Date, Assessment Date, or Maintenance Date.\",\"priority\":\"Medium\"},{\"scenarioId\":\"TS_008\",\"title\":\"Use Eligibility Date for future new enrollment regardless of Assessment Date\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that for an inbound new enrollment where the member eligibility span has not yet begun, the transaction effective date in Facets is populated with the Eligibility Date even when Assessment Date differs.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_009\",\"title\":\"Use Eligibility Date when future eligibility and Assessment Date is earlier\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that for future eligibility spans the Eligibility Date is used as transaction effective date when Assessment Date is earlier than the Eligibility Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_010\",\"title\":\"Do not use Assessment or Maintenance Date for future eligibility enrollment\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that for a member whose eligibility span has not yet begun, Assessment Date and Maintenance Date are not used as the transaction effective date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_011\",\"title\":\"Use Assessment Date when current eligibility exists and Assessment Date changes\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when the member eligibility span has already begun and the inbound Assessment Date changes, the transaction effective date in Facets is populated with the Assessment Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_012\",\"title\":\"Use changed Assessment Date for current eligibility regardless of Eligibility Date value\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that for current eligibility the changed Assessment Date is selected as transaction effective date even when the Eligibility Date remains unchanged or differs.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_013\",\"title\":\"Do not use Maintenance Date when current eligibility Assessment Date changed\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used as the transaction effective date when current eligibility exists and the Assessment Date has changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_014\",\"title\":\"Use Assessment Date when only Assessment Date changes and relevant fields remain unchanged\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Positive\",\"description\":\"Validate that when Assessment Date changes and Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, and Pregnancy remain unchanged, the Assessment Date populates as the transaction effective date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_015\",\"title\":\"Maintain relevant field values when only Assessment Date changes\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Positive\",\"description\":\"Validate that relevant field values are preserved in Facets when Assessment Date changes but no relevant field change is received.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_016\",\"title\":\"Detect relevant field change and avoid AC5 path\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Negative\",\"description\":\"Validate that AC5 logic is not applied when any relevant field among Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy has changed along with Assessment Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_017\",\"title\":\"Use Eligibility Date for future eligibility with relevant field changes and unchanged Assessment Date\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when eligibility has not yet begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with the Eligibility Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_018\",\"title\":\"Apply Eligibility Date for each relevant field change before eligibility start\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that Eligibility Date is used as transaction effective date when any single relevant field change is received before eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_019\",\"title\":\"Do not use Maintenance Date before eligibility start when Assessment Date is unchanged\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used as the transaction effective date when relevant field changes are received before eligibility start and Assessment Date is unchanged.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_020\",\"title\":\"Use Maintenance Date for current eligibility with relevant field changes and unchanged Assessment Date\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when eligibility has already begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with Maintenance Date DTP*303.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_021\",\"title\":\"Apply Maintenance Date for each relevant field change after eligibility start\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that Maintenance Date is used as transaction effective date when any single relevant field change is received after eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_022\",\"title\":\"Do not use Eligibility Date for current eligibility relevant field changes when Assessment Date is unchanged\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Eligibility Date is not used as the transaction effective date when relevant field changes are received after eligibility start and Assessment Date is unchanged.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_023\",\"title\":\"Maintenance Date used only in explicitly allowed scenario\",\"acceptanceCriteriaRef\":\"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.\",\"type\":\"Positive\",\"description\":\"Validate that Maintenance Date is used only for inbound changes to relevant fields when eligibility has already begun and Assessment Date has not changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_024\",\"title\":\"Prevent Maintenance Date usage for new enrollment and Assessment Date change scenarios\",\"acceptanceCriteriaRef\":\"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used for new enrollments, future eligibility updates, or scenarios where Assessment Date has changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_025\",\"title\":\"Regression coverage for mixed inbound combinations of dates and relevant field changes\",\"acceptanceCriteriaRef\":\"QA Regression - Test inbound 834 files with varying combinations of Eligibility Date, Assessment Date changes, and relevant field changes to verify correct transaction effective date population.\",\"type\":\"Edge\",\"description\":\"Validate correct transaction effective date selection across mixed inbound combinations of future eligibility, current eligibility, Assessment Date changes, and relevant field changes in repeated 2000 and 2300 loop occurrences.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_026\",\"title\":\"Verify no finance-impacting regression from effective date logic update\",\"acceptanceCriteriaRef\":\"QA Regression - Verify no change in capitation calculations and accurate reporting for finance team.\",\"type\":\"Positive\",\"description\":\"Validate that the updated inbound transaction effective date logic does not introduce capitation calculation mismatches or finance reporting inaccuracies downstream.\",\"priority\":\"Medium\"},{\"scenarioId\":\"TS_027\",\"title\":\"Flag knowledge gap when Assessment Date source conflicts with acceptance criteria wording\",\"acceptanceCriteriaRef\":\"AC1-AC7 - Technical Notes and Acceptance Criteria alignment\",\"type\":\"Edge\",\"description\":\"Validate rule execution while flagging that technical notes identify Assessment Date at Loop 2300 HD03 and acceptance criteria reference date-based logic, so any source-field ambiguity must be recorded without blocking remaining scenario coverage.\",\"priority\":\"Low\"}]",
      "Add coverage for all missing scenarios TS_001-TS_007, TS_009, TS_011-TS_027; split any per-relevant-field edge coverage into atomic cases instead of one bundled case; align preconditions to each scenario instead of generic environment/setup text.": "Add coverage for missing scenarios TS_002-TS_007 and TS_009-TS_027; add explicit negative/edge cases for AC1 and AC3 (TS_002, TS_003, TS_009, TS_010); remove non-scenario-grounded DB/crosswalk checks from TC_001; and ensure each test case validates only scenario-required behavior with relevant preconditions."
    }
  },
  "confidence_score": 32
}
```
### ✅ Agent Test Case Reviewer LLM as a Judge Test4 wf2 Finished
**Message:**  
[Agent] ✅ 'Test Case Reviewer LLM as a Judge Test4 wf2' finished
{"confidence":32,"approved":false,"feedback":"Add coverage for missing scenarios TS_002-TS_007 and TS_009-TS_027; add explicit negative/edge cases for AC1 and AC3 (TS_002, TS_003, TS_009, TS_010); remove non-scenario-grounded DB/crosswalk checks from TC_001; and ensure each test case validates only scenario-required behavior with relevant preconditions.","strengths":["Traceability fields are present and the two existing cases clearly map to TS_001/AC1 and TS_008/AC3.","Steps are mostly concrete and executable with specific file paths, segment values, and system touchpoints.","Preconditions for the two covered scenarios are detailed and scenario-specific rather than generic setup text."],"gaps":["Scenario coverage is severely incomplete: only TS_001 and TS_008 have test cases; TS_002-TS_007 and TS_009-TS_027 have zero corresponding test cases.","Negative and edge coverage required by scenario types is missing: TS_002, TS_003, TS_009, TS_010 and all other Negative/Edge scenarios have no matching cases.","TC_001 includes non-scenario-grounded validations such as MELC/crosswalk SQL checks that do not trace to AC1 date identification behavior.","TC_001 precondition and steps mix multiple mechanisms beyond simple date identification (file transport, archive verification, DB crosswalk checks, Facets member review), weakening atomic focus for TS_001.","No test case covers AC2, AC4, AC5, AC6, AC7, QA Regression, or the technical-alignment scenario TS_027, so traceability to most acceptance criteria is absent."],"scenariojson":"[{\"scenarioId\":\"TS_001\",\"title\":\"Identify Eligibility, Assessment, and Maintenance Dates from inbound 834\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Positive\",\"description\":\"Validate that inbound EDI 834 processing identifies Eligibility Date from Loop 2000 DTP*356/DTP*348, Assessment Date from Loop 2300 HD03, and Maintenance Date from DTP*303 for transaction effective date evaluation.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_002\",\"title\":\"Identify first occurrence when multiple date values are received\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Edge\",\"description\":\"Validate that when multiple inbound date occurrences are present, the first applicable date is identified and used per technical guidance.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_003\",\"title\":\"Handle missing required date elements during date identification\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Negative\",\"description\":\"Validate that inbound processing flags a date identification gap when one or more of Eligibility Date, Assessment Date, or Maintenance Date required for rule evaluation are missing from the 834.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_004\",\"title\":\"Populate Facets transaction effective date with identified Eligibility Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Eligibility Date can be populated into the Facets transaction effective date field.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_005\",\"title\":\"Populate Facets transaction effective date with identified Assessment Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Assessment Date can be populated into the Facets transaction effective date field.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_006\",\"title\":\"Populate Facets transaction effective date with identified Maintenance Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Maintenance Date can be populated into the Facets transaction effective date field when selected by business rules.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_007\",\"title\":\"Prevent unsupported date population to Facets transaction effective date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Negative\",\"description\":\"Validate that Facets transaction effective date is not populated from any inbound date other than the identified Eligibility Date, Assessment Date, or Maintenance Date.\",\"priority\":\"Medium\"},{\"scenarioId\":\"TS_008\",\"title\":\"Use Eligibility Date for future new enrollment regardless of Assessment Date\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that for an inbound new enrollment where the member eligibility span has not yet begun, the transaction effective date in Facets is populated with the Eligibility Date even when Assessment Date differs.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_009\",\"title\":\"Use Eligibility Date when future eligibility and Assessment Date is earlier\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that for future eligibility spans the Eligibility Date is used as transaction effective date when Assessment Date is earlier than the Eligibility Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_010\",\"title\":\"Do not use Assessment or Maintenance Date for future eligibility enrollment\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that for a member whose eligibility span has not yet begun, Assessment Date and Maintenance Date are not used as the transaction effective date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_011\",\"title\":\"Use Assessment Date when current eligibility exists and Assessment Date changes\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when the member eligibility span has already begun and the inbound Assessment Date changes, the transaction effective date in Facets is populated with the Assessment Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_012\",\"title\":\"Use changed Assessment Date for current eligibility regardless of Eligibility Date value\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that for current eligibility the changed Assessment Date is selected as transaction effective date even when the Eligibility Date remains unchanged or differs.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_013\",\"title\":\"Do not use Maintenance Date when current eligibility Assessment Date changed\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used as the transaction effective date when current eligibility exists and the Assessment Date has changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_014\",\"title\":\"Use Assessment Date when only Assessment Date changes and relevant fields remain unchanged\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Positive\",\"description\":\"Validate that when Assessment Date changes and Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, and Pregnancy remain unchanged, the Assessment Date populates as the transaction effective date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_015\",\"title\":\"Maintain relevant field values when only Assessment Date changes\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Positive\",\"description\":\"Validate that relevant field values are preserved in Facets when Assessment Date changes but no relevant field change is received.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_016\",\"title\":\"Detect relevant field change and avoid AC5 path\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Negative\",\"description\":\"Validate that AC5 logic is not applied when any relevant field among Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy has changed along with Assessment Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_017\",\"title\":\"Use Eligibility Date for future eligibility with relevant field changes and unchanged Assessment Date\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when eligibility has not yet begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with the Eligibility Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_018\",\"title\":\"Apply Eligibility Date for each relevant field change before eligibility start\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that Eligibility Date is used as transaction effective date when any single relevant field change is received before eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_019\",\"title\":\"Do not use Maintenance Date before eligibility start when Assessment Date is unchanged\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used as the transaction effective date when relevant field changes are received before eligibility start and Assessment Date is unchanged.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_020\",\"title\":\"Use Maintenance Date for current eligibility with relevant field changes and unchanged Assessment Date\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when eligibility has already begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with Maintenance Date DTP*303.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_021\",\"title\":\"Apply Maintenance Date for each relevant field change after eligibility start\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that Maintenance Date is used as transaction effective date when any single relevant field change is received after eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_022\",\"title\":\"Do not use Eligibility Date for current eligibility relevant field changes when Assessment Date is unchanged\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Eligibility Date is not used as the transaction effective date when relevant field changes are received after eligibility start and Assessment Date is unchanged.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_023\",\"title\":\"Maintenance Date used only in explicitly allowed scenario\",\"acceptanceCriteriaRef\":\"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.\",\"type\":\"Positive\",\"description\":\"Validate that Maintenance Date is used only for inbound changes to relevant fields when eligibility has already begun and Assessment Date has not changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_024\",\"title\":\"Prevent Maintenance Date usage for new enrollment and Assessment Date change scenarios\",\"acceptanceCriteriaRef\":\"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used for new enrollments, future eligibility updates, or scenarios where Assessment Date has changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_025\",\"title\":\"Regression coverage for mixed inbound combinations of dates and relevant field changes\",\"acceptanceCriteriaRef\":\"QA Regression - Test inbound 834 files with varying combinations of Eligibility Date, Assessment Date changes, and relevant field changes to verify correct transaction effective date population.\",\"type\":\"Edge\",\"description\":\"Validate correct transaction effective date selection across mixed inbound combinations of future eligibility, current eligibility, Assessment Date changes, and relevant field changes in repeated 2000 and 2300 loop occurrences.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_026\",\"title\":\"Verify no finance-impacting regression from effective date logic update\",\"acceptanceCriteriaRef\":\"QA Regression - Verify no change in capitation calculations and accurate reporting for finance team.\",\"type\":\"Positive\",\"description\":\"Validate that the updated inbound transaction effective date logic does not introduce capitation calculation mismatches or finance reporting inaccuracies downstream.\",\"priority\":\"Medium\"},{\"scenarioId\":\"TS_027\",\"title\":\"Flag knowledge gap when Assessment Date source conflicts with acceptance criteria wording\",\"acceptanceCriteriaRef\":\"AC1-AC7 - Technical Notes and Acceptance Criteria alignment\",\"type\":\"Edge\",\"description\":\"Validate rule execution while flagging that technical notes identify Assessment Date at Loop 2300 HD03 and acceptance criteria reference date-based logic, so any source-field ambiguity must be recorded without blocking remaining scenario coverage.\",\"priority\":\"Low\"}]"}
### 🎯 Task Finished
**Message:**  
[Task] ✅ Task finished
{"confidence":32,"approved":false,"feedback":"Add coverage for missing scenarios TS_002-TS_007 and TS_009-TS_027; add explicit negative/edge cases for AC1 and AC3 (TS_002, TS_003, TS_009, TS_010); remove non-scenario-grounded DB/crosswalk checks from TC_001; and ensure each test case validates only scenario-required behavior with relevant preconditions.","strengths":["Traceability fields are present and the two existing cases clearly map to TS_001/AC1 and TS_008/AC3.","Steps are mostly concrete and executable with specific file paths, segment values, and system touchpoints.","Preconditions for the two covered scenarios are detailed and scenario-specific rather than generic setup text."],"gaps":["Scenario coverage is severely incomplete: only TS_001 and TS_008 have test cases; TS_002-TS_007 and TS_009-TS_027 have zero corresponding test cases.","Negative and edge coverage required by scenario types is missing: TS_002, TS_003, TS_009, TS_010 and all other Negative/Edge scenarios have no matching cases.","TC_001 includes non-scenario-grounded validations such as MELC/crosswalk SQL checks that do not trace to AC1 date identification behavior.","TC_001 precondition and steps mix multiple mechanisms beyond simple date identification (file transport, archive verification, DB crosswalk checks, Facets member review), weakening atomic focus for TS_001.","No test case covers AC2, AC4, AC5, AC6, AC7, QA Regression, or the technical-alignment scenario TS_027, so traceability to most acceptance criteria is absent."],"scenariojson":"[{\"scenarioId\":\"TS_001\",\"title\":\"Identify Eligibility, Assessment, and Maintenance Dates from inbound 834\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Positive\",\"description\":\"Validate that inbound EDI 834 processing identifies Eligibility Date from Loop 2000 DTP*356/DTP*348, Assessment Date from Loop 2300 HD03, and Maintenance Date from DTP*303 for transaction effective date evaluation.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_002\",\"title\":\"Identify first occurrence when multiple date values are received\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Edge\",\"description\":\"Validate that when multiple inbound date occurrences are present, the first applicable date is identified and used per technical guidance.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_003\",\"title\":\"Handle missing required date elements during date identification\",\"acceptanceCriteriaRef\":\"AC1 - EDI is able to identify the following dates in the EDI 834 file (existing functionality): Effective Date, Assessment Date, Maintenance Date.\",\"type\":\"Negative\",\"description\":\"Validate that inbound processing flags a date identification gap when one or more of Eligibility Date, Assessment Date, or Maintenance Date required for rule evaluation are missing from the 834.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_004\",\"title\":\"Populate Facets transaction effective date with identified Eligibility Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Eligibility Date can be populated into the Facets transaction effective date field.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_005\",\"title\":\"Populate Facets transaction effective date with identified Assessment Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Assessment Date can be populated into the Facets transaction effective date field.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_006\",\"title\":\"Populate Facets transaction effective date with identified Maintenance Date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Positive\",\"description\":\"Validate that the identified Maintenance Date can be populated into the Facets transaction effective date field when selected by business rules.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_007\",\"title\":\"Prevent unsupported date population to Facets transaction effective date\",\"acceptanceCriteriaRef\":\"AC2 - Enrollment IT can populate any of the three dates above into the transaction effective date in Facets (existing functionality).\",\"type\":\"Negative\",\"description\":\"Validate that Facets transaction effective date is not populated from any inbound date other than the identified Eligibility Date, Assessment Date, or Maintenance Date.\",\"priority\":\"Medium\"},{\"scenarioId\":\"TS_008\",\"title\":\"Use Eligibility Date for future new enrollment regardless of Assessment Date\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that for an inbound new enrollment where the member eligibility span has not yet begun, the transaction effective date in Facets is populated with the Eligibility Date even when Assessment Date differs.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_009\",\"title\":\"Use Eligibility Date when future eligibility and Assessment Date is earlier\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that for future eligibility spans the Eligibility Date is used as transaction effective date when Assessment Date is earlier than the Eligibility Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_010\",\"title\":\"Do not use Assessment or Maintenance Date for future eligibility enrollment\",\"acceptanceCriteriaRef\":\"AC3 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun, the Eligibility Date (DTP*356/DTP*348) populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that for a member whose eligibility span has not yet begun, Assessment Date and Maintenance Date are not used as the transaction effective date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_011\",\"title\":\"Use Assessment Date when current eligibility exists and Assessment Date changes\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when the member eligibility span has already begun and the inbound Assessment Date changes, the transaction effective date in Facets is populated with the Assessment Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_012\",\"title\":\"Use changed Assessment Date for current eligibility regardless of Eligibility Date value\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that for current eligibility the changed Assessment Date is selected as transaction effective date even when the Eligibility Date remains unchanged or differs.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_013\",\"title\":\"Do not use Maintenance Date when current eligibility Assessment Date changed\",\"acceptanceCriteriaRef\":\"AC4 - Given an inbound EDI 834 file, if the member eligibility span has already begun and the Assessment Date has changed, the Assessment Date populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used as the transaction effective date when current eligibility exists and the Assessment Date has changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_014\",\"title\":\"Use Assessment Date when only Assessment Date changes and relevant fields remain unchanged\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Positive\",\"description\":\"Validate that when Assessment Date changes and Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, and Pregnancy remain unchanged, the Assessment Date populates as the transaction effective date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_015\",\"title\":\"Maintain relevant field values when only Assessment Date changes\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Positive\",\"description\":\"Validate that relevant field values are preserved in Facets when Assessment Date changes but no relevant field change is received.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_016\",\"title\":\"Detect relevant field change and avoid AC5 path\",\"acceptanceCriteriaRef\":\"AC5 - Given an inbound EDI 834 file, if the Assessment Date has changed and none of the relevant fields have changed, the Assessment Date populates as the transaction effective date, maintaining values of relevant fields.\",\"type\":\"Negative\",\"description\":\"Validate that AC5 logic is not applied when any relevant field among Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy has changed along with Assessment Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_017\",\"title\":\"Use Eligibility Date for future eligibility with relevant field changes and unchanged Assessment Date\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when eligibility has not yet begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with the Eligibility Date.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_018\",\"title\":\"Apply Eligibility Date for each relevant field change before eligibility start\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that Eligibility Date is used as transaction effective date when any single relevant field change is received before eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_019\",\"title\":\"Do not use Maintenance Date before eligibility start when Assessment Date is unchanged\",\"acceptanceCriteriaRef\":\"AC6 - Given an inbound EDI 834 file, if the member’s eligibility span has not yet begun and any relevant fields have changed but Assessment Date has NOT changed, the Eligibility Date populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used as the transaction effective date when relevant field changes are received before eligibility start and Assessment Date is unchanged.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_020\",\"title\":\"Use Maintenance Date for current eligibility with relevant field changes and unchanged Assessment Date\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Positive\",\"description\":\"Validate that when eligibility has already begun, one or more relevant fields change, and Assessment Date does not change, the transaction effective date is populated with Maintenance Date DTP*303.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_021\",\"title\":\"Apply Maintenance Date for each relevant field change after eligibility start\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Edge\",\"description\":\"Validate that Maintenance Date is used as transaction effective date when any single relevant field change is received after eligibility start with unchanged Assessment Date, including Assessment Number, Assessment Tier, Assessment Division, Aid Category, Rate Cell, or Pregnancy.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_022\",\"title\":\"Do not use Eligibility Date for current eligibility relevant field changes when Assessment Date is unchanged\",\"acceptanceCriteriaRef\":\"AC7 - Given an inbound EDI 834 file, if the member’s eligibility span has already begun and any relevant fields have changed but Assessment Date has NOT changed, the Maintenance Date (DTP*303) populates as the transaction effective date.\",\"type\":\"Negative\",\"description\":\"Validate that Eligibility Date is not used as the transaction effective date when relevant field changes are received after eligibility start and Assessment Date is unchanged.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_023\",\"title\":\"Maintenance Date used only in explicitly allowed scenario\",\"acceptanceCriteriaRef\":\"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.\",\"type\":\"Positive\",\"description\":\"Validate that Maintenance Date is used only for inbound changes to relevant fields when eligibility has already begun and Assessment Date has not changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_024\",\"title\":\"Prevent Maintenance Date usage for new enrollment and Assessment Date change scenarios\",\"acceptanceCriteriaRef\":\"QA Regression - Confirm that Maintenance Date is only used when specified in acceptance criteria.\",\"type\":\"Negative\",\"description\":\"Validate that Maintenance Date is not used for new enrollments, future eligibility updates, or scenarios where Assessment Date has changed.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_025\",\"title\":\"Regression coverage for mixed inbound combinations of dates and relevant field changes\",\"acceptanceCriteriaRef\":\"QA Regression - Test inbound 834 files with varying combinations of Eligibility Date, Assessment Date changes, and relevant field changes to verify correct transaction effective date population.\",\"type\":\"Edge\",\"description\":\"Validate correct transaction effective date selection across mixed inbound combinations of future eligibility, current eligibility, Assessment Date changes, and relevant field changes in repeated 2000 and 2300 loop occurrences.\",\"priority\":\"High\"},{\"scenarioId\":\"TS_026\",\"title\":\"Verify no finance-impacting regression from effective date logic update\",\"acceptanceCriteriaRef\":\"QA Regression - Verify no change in capitation calculations and accurate reporting for finance team.\",\"type\":\"Positive\",\"description\":\"Validate that the updated inbound transaction effective date logic does not introduce capitation calculation mismatches or finance reporting inaccuracies downstream.\",\"priority\":\"Medium\"},{\"scenarioId\":\"TS_027\",\"title\":\"Flag knowledge gap when Assessment Date source conflicts with acceptance criteria wording\",\"acceptanceCriteriaRef\":\"AC1-AC7 - Technical Notes and Acceptance Criteria alignment\",\"type\":\"Edge\",\"description\":\"Validate rule execution while flagging that technical notes identify Assessment Date at Loop 2300 HD03 and acceptance criteria reference date-based logic, so any source-field ambiguity must be recorded without blocking remaining scenario coverage.\",\"priority\":\"Low\"}]"}