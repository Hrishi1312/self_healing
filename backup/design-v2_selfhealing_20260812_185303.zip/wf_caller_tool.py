import requests
from typing import Any, Dict, Type
from pydantic import BaseModel, Field, model_validator
from crewai.tools import BaseTool
import json
import AVASecret

# Confidence threshold below which the workflow is triggered for re-execution.
_CONFIDENCE_THRESHOLD = 80

# Priority is always hardcoded; it is not received from the agent.
_PRIORITY = 1


class RestApiFormDataCallerSchema(BaseModel):
    """Input schema for RestApiFormDataCaller."""

    form_data: Dict[str, Any] = Field(
        ...,
        description=(
            "The full workflow execution payload dict containing: "
            "pipelineId (int), userInputs (dict with keys "
            "{{tsInputJson_string_true}}, {{rvwFeedbackTxt_string_false}}). "
            "Do NOT include priority."
        ),
    )
    confidence_score: int = Field(
        ..., description="Confidence score of the reviewer agent (0-100)."
    )

    @model_validator(mode="before")
    @classmethod
    def _lift(cls, v):
        # The model sometimes nests confidence_score inside form_data. Lift it
        # out to the top level so validation succeeds instead of fighting it.
        if isinstance(v, dict) and "confidence_score" not in v:
            fd = v.get("form_data") or {}
            if "confidence_score" in fd:
                v["confidence_score"] = fd.pop("confidence_score")
        return v


class RestApiFormDataCaller(BaseTool):
    """
    RestApiFormDataCaller - Receives workflow input data and the reviewer
    confidence score, checks the confidence against the threshold, and triggers
    a workflow re-execution via the AAVA workflow API if it is below the
    threshold. If the score meets or exceeds the threshold, no API call is made.
    """

    name: str = "REST API Form Data Caller"
    description: str = (
        "Receives workflow input data and the reviewer confidence score. "
        "Triggers a workflow re-execution via the AAVA workflow API "
        "when the confidence score is below threshold."
    )
    args_schema: Type[BaseModel] = RestApiFormDataCallerSchema

    def _run(self, form_data: Dict[str, Any], confidence_score: int) -> str:
        try:
            api_url = "https://aava-core-api-workflows-svc.redtree-f4541a84.eastus.azurecontainerapps.io/workflows/workflow-executions"

            # pat_token = AVASecret.getValue("KEY")
            pat_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJIcmlzaGlrZXNoIFJvZGUiLCJpYXQiOjE3ODU4MzM3NDEsImV4cCI6MTc5ODc2MTU5OSwiYXBwaWQiOiIyZTAwNzA4ZS05ZjZlLTQxODYtOWQxNy04MTRjZjI1YWI2M2EiLCJ1bmlxdWVfbmFtZSI6IkhyaXNoaWtlc2guUm9kZUBjYXJlc291cmNlLmNvbSIsImRvbWFpbiI6ImFhdmEtY29yZS1hcGktYXV0aC1zdmMucmVkdHJlZS1mNDU0MWE4NC5lYXN0dXMuYXp1cmVjb250YWluZXJhcHBzLmlvIiwidXNlckRldGFpbHMiOiJyRnR6Q0J4MkpWbGtjNHU0UlRZQ0RGcjRDaGhsM0NEWDdWb2Z0Y2R1WGc1REZ1Z1VCSXFQSjIzRFV2TzVGajR6OHVBRnZLam9rMjhrRWhmSGxra1F5a1J4QmpVci94UEtsRHdVMkVUdko0SVhJY1ZJZ3lVQ2pPNzlYWmVIRm1pQ052SDd5bU04UCtNUmpIMEt0RFI3ME9OdWNUZzZwOTYrOHNjc0h1Q2hXdVBjZ0JGRFl1UlhGVGhUVXVvMHRiZFRuOGNjZDcwVHYrRStpTys2Y2M4NUNHa0ZlTkhxNHBid0JNRUhMdjBpSXNJPSJ9.J1vMecZNQdN9F2v_mJe4G5iDok6Fy7KnYB2DUSDxTpuw_ZBqmNF19i5ewpBBsUZbaf8xZN4PHdjTrtjgBj_ewHr2jMhlOQGMU8luPEYwpX1vi28H8wRFepN5k-tMB6YVnQ0jnU5HcjtoKeTyuDVf6oXIty8v41B7hVI1hjFqdDlL0G_gwoRSFbFjatsjYv4_QlRAhmD6w8L6S3oqTrO37PvgO4u-ltIGuK4DZMUIUh6mJT7Od9IUEBTr6wlWp_SoiaqKMe-4yUT-_VpHpl1CWHGY4wyCB9deXi9sYb33khWLRYwh8Q68M3pIBUktezw-66ttLSNe0tSxYGUjKZPhQg"

            headers = {
                "Authorization": f"Bearer {pat_token}",
            }

            if confidence_score <= 30:
                return (
                    "Error: confidence score is too low. Aborting - no valid reviewer "
                    "confidence was produced, so the workflow will not be triggered."
                )

            if confidence_score >= _CONFIDENCE_THRESHOLD:
                return (
                    f"Confidence score {confidence_score} meets threshold "
                    f"({_CONFIDENCE_THRESHOLD}). No workflow re-execution needed."
                )

            # Override priority with the hardcoded value (not from agent).
            form_data["priority"] = _PRIORITY

            # Normalize all values to strings for multipart form-data encoding.
            # Nested dicts/lists are JSON-serialized.
            def normalize_form_data(data: dict) -> dict:
                normalized = {}
                for key, value in data.items():
                    if isinstance(value, (dict, list)):
                        normalized[key] = json.dumps(value)
                    elif value is None:
                        normalized[key] = ""
                    else:
                        normalized[key] = str(value)
                return normalized

            # AAVA substitutes {{var}} tokens inside the prompt, so the reviewer's
            # userInputs keys arrive holding their own values. Re-key them here.
            # Map the reviewer agent's userInputs directly to the workflow variables.
            # The reviewer prompt always sends:
            #   - tsInputJson
            #   - rvwFeedbackTxt
            #   - reviewinputs (optional)
            #
            # Convert them into the workflow variable names expected by AAVA.
            ui = form_data.get("userInputs") or {}

            form_data["userInputs"] = {
                "tsInputJson_string_true": ui.get("tsInputJson", ""),
                "rvwFeedbackTxt_string_false": ui.get("rvwFeedbackTxt", ""),
                "reviewinputs": ui.get("reviewinputs", ""),
            }

            normalized = normalize_form_data(form_data)

            response = requests.post(
                api_url,
                files={k: (None, v) for k, v in normalized.items()},
                headers=headers,
            )
            response.raise_for_status()

            try:
                return (
                    f"Confidence score {confidence_score} is below threshold "
                    f"({_CONFIDENCE_THRESHOLD}). Workflow triggered successfully. "
                    f"Response: {response.json()}"
                )
            except Exception:
                return (
                    f"Confidence score {confidence_score} is below threshold "
                    f"({_CONFIDENCE_THRESHOLD}). Workflow triggered successfully. "
                    f"Response: {response.text}"
                )

        except requests.RequestException as e:
            return f"Error during API call: {str(e)}"